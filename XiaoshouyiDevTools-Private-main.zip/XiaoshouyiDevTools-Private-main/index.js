let injectFile = document.getElementById("inject-file");
var selectId = document.getElementById("sel2");
var objectChange = "Add Login Link";
var selectHttpsId = document.getElementById("httpsSel");
var objecthttpChange = "https://crm.xiaoshouyi.com";

var loginhtmlarr;
var state;
var eidtKey;
var hrefUrl;
var httpOldTime;
var decryptKey = "A1B1C3D4S5G6H7P8";
var customhttpstate = false;

$(function () {
  injectFile.click();
});

var binded = false;
function bindeHandler() {
  if (!binded) {
    binded = true;
    mess();
    let messName = "myConnect";
    let message = {};
    mess(messName, message);
    window.close();
  }
}

async function getCurrentTab() {
  let queryOptions = { active: true, currentWindow: true };
  let [tab] = await chrome.tabs.query(queryOptions);
  return tab;
}

injectFile.addEventListener("click", async () => {
  let tab = await getCurrentTab();
  hrefUrl = tab.url;
  var url = new URL(hrefUrl);
  var urlhost = url.host;
  var urlhostUpper = urlhost.toUpperCase();
  var result = url.pathname;
  if (
    result == "/auc/oauth2/auth" ||
    urlhostUpper.indexOf("XIAOSHOUYI.COM") == -1
  ) {
    addotherlink("indexhtml");
  } else {
    bindeHandler();
  }
});

$("#httpsSel").on("change", function () {
  var httpChange = selectHttpsId.options[selectHttpsId.selectedIndex].value;
  if (httpChange == "Others") {
    customhttpstate = true;
    document.getElementById("otherLoginInput").style.display = "block";
    objecthttpChange = document.getElementById("otherLoginInput").value;
  } else {
    customhttpstate = false;
    document.getElementById("otherLoginInput").style.display = "none";
    objecthttpChange = selectHttpsId.options[selectHttpsId.selectedIndex].value;
  }
});

$("#sel2").on("change", function () {
  objectChange = selectId.options[selectId.selectedIndex].value;
  if (objectChange == "Add Useful Link") {
    document.getElementById("loginLinkDiv").style.display = "none";
    document.getElementById("userLinkDiv").style.display = "";
  } else {
    document.getElementById("loginLinkDiv").style.display = "";
    document.getElementById("userLinkDiv").style.display = "none";
  }
});

$(document).on("click", "#backbutton", function () {
  document.getElementById("otherLink").style.display = "";
  document.getElementById("backbutton").style.display = "none";
  var getselectOrganization = document.getElementById("selectOrganization");
  getselectOrganization.style.display = "none";
  getselectOrganization.innerHTML = "";
});

$(document).on("click", "#otherLink .otherlinkli", function () {
  var linkHeight = document.getElementById("otherLink").offsetHeight;
  if ($(this).attr("index") == "userful") {
    window.open($(this).attr("className"), "_blank");
  } else {
    var pwd = CryptoJS.AES.decrypt(
      $(this).attr("className"),
      decryptKey
    ).toString(CryptoJS.enc.Utf8);
    if ($(this).attr("index") != "") {
      posturlfun(
        $(this).attr("index"),
        $(this).attr("indexOf"),
        pwd,
        linkHeight,
        'indexheml'
      );
    } else {
      posturlfun(objecthttpChange, $(this).attr("indexOf"), pwd, linkHeight, 'indexheml');
    }
  }
});

$(document).on("click", "#buttonDiv button", function (event) {
  event.stopPropagation();
  if ($(this).attr("class") == "eidtbutton") {
    state = "Edit";
    eidtKey = $(this).attr("id");
    httpOldTime = $(this).attr("oldTime");
    if ($(this).attr("index") == "userful") {
      document.getElementById("urlname").value = $(this).attr("indexOf");
      document.getElementById("inputLink").value = $(this).attr("className");
      document.getElementById("UsefulLInk").selected = "selected";
      objectChange = selectId.options[selectId.selectedIndex].value;
      document.getElementById("loginLinkDiv").style.display = "none";
      document.getElementById("userLinkDiv").style.display = "";
    } else {
      if ($(this).attr("customHttpLink") != "true") {
        customhttpstate = false;
        document.getElementById("otherLoginInput").style.display = "none";
        document.getElementById($(this).attr("index")).selected = "selected";
        objecthttpChange =
          selectHttpsId.options[selectHttpsId.selectedIndex].value;
      } else {
        customhttpstate = true;
        document.getElementById("otherLoginInput").style.display = "block";
        document.getElementById("otherLoginLink").selected = "selected";
        document.getElementById("otherLoginInput").value =
          $(this).attr("index");
        objecthttpChange = document.getElementById("otherLoginInput").value;
      }
      document.getElementById("loginName").value = $(this).attr("indexOf");
      var pwd = CryptoJS.AES.decrypt(
        $(this).attr("className"),
        decryptKey
      ).toString(CryptoJS.enc.Utf8);
      document.getElementById("Password").value = pwd;
      document.getElementById("linkTitle").value = $(this).attr("customin");
      document.getElementById("loginLink").selected = "selected";
      objectChange = selectId.options[selectId.selectedIndex].value;
      document.getElementById("loginLinkDiv").style.display = "";
      document.getElementById("userLinkDiv").style.display = "none";
    }
  } else if ($(this).attr("class") == "delbutton") {
    var deletekey = $(this).attr("id");
    localStorage.removeItem(deletekey);
    $("#otherLink").find("li").remove();
    initialization();
    addotherlink("indexhtml");
  }
});

$(document).on("click", "#selectOrganization li", function () {
  var posturl = $(this).attr("indexOf");
  $.ajax({
    type: "POST",
    url: posturl + "/global/login-entry.action",
    data: {
      tenantId: $(this).attr("Id"),
      "passport.id": $(this).attr("class"),
      encryptionKey: $(this).attr("className"),
      loginName: $(this).attr("index"),
    },
    success: function (str_response) {
      window.open(posturl);
    },
  });
});

$("#button").click(function () {
  state = "Add";
  document.getElementById("otherLoginInput").style.display = "none";	
});

$("#save").click(function () {
  var uelnamestr;
  var loginNamestr;

  var uelname;
  var inputLink;

  var loginName;
  var password;
  var logintitle;
  if (customhttpstate) {
    objecthttpChange = document.getElementById("otherLoginInput").value;
  }
  if (objectChange == "Add Useful Link") {
    uelname = document.getElementById("urlname").value;
    uelnamestr = "userful__" + uelname;
    inputLink = document.getElementById("inputLink").value;
    if (!checkerror(uelname, inputLink, true, "",objecthttpChange,customhttpstate)) {
      return false;
    }
  } else {
    loginName = document.getElementById("loginName").value;
    if (!customhttpstate) {
      loginNamestr = objecthttpChange + loginName;
    } else {
      objecthttpChange = document.getElementById("otherLoginInput").value;
      loginNamestr = objecthttpChange + loginName;
    }
    password = document.getElementById("Password").value;
    var paswE = CryptoJS.AES.encrypt(password, decryptKey).toString();
    logintitle = document.getElementById("linkTitle").value;
    if (!checkerror(loginName, password, false, logintitle,objecthttpChange,customhttpstate)) {
      return false;
    }
  }

  if (state == "Add") {
    var httpTime = new Date();
    var nowDate = httpTime.getTime();
    if (objectChange == "Add Useful Link") {
      if (!ischeckrepeat(uelnamestr, true)) {
        return false;
      }
      var setvalue = getJasonStr(
        "",
        "",
        "",
        uelname,
        inputLink,
        "userful",
        nowDate,
        uelnamestr,
        customhttpstate
      );
      localStorage.setItem(uelnamestr, setvalue);
    } else {
      if (!ischeckrepeat(loginNamestr, false)) {
        return false;
      }
      var setvalue = getJasonStr(
        loginName,
        paswE,
        logintitle,
        uelname,
        inputLink,
        objecthttpChange,
        nowDate,
        loginNamestr,
        customhttpstate
      );
      localStorage.setItem(loginNamestr, setvalue);
    }
  } else if (state == "Edit") {
    if (objectChange == "Add Useful Link") {
      if (uelnamestr == eidtKey) {
        var setvalue = getJasonStr(
          "",
          "",
          "",
          uelname,
          inputLink,
          "userful",
          httpOldTime,
          uelnamestr,
          customhttpstate
        );
        localStorage.setItem(uelnamestr, setvalue);
      } else {
        if (!ischeckrepeat(uelnamestr, true)) {
          return false;
        }
        localStorage.removeItem(eidtKey);
        var setvalue = getJasonStr(
          "",
          "",
          "",
          uelname,
          inputLink,
          "userful",
          httpOldTime,
          uelnamestr,
          customhttpstate
        );
        localStorage.setItem(uelnamestr, setvalue);
      }
    } else {
      if (loginNamestr == eidtKey) {
        var setvalue = getJasonStr(
          loginName,
          paswE,
          logintitle,
          uelname,
          inputLink,
          objecthttpChange,
          httpOldTime,
          loginNamestr,
          customhttpstate
        );
        localStorage.setItem(loginNamestr, setvalue);
      } else {
        if (!ischeckrepeat(loginNamestr, false)) {
          return false;
        }
        localStorage.removeItem(eidtKey);
        var setvalue = getJasonStr(
          loginName,
          paswE,
          logintitle,
          uelname,
          inputLink,
          objecthttpChange,
          httpOldTime,
          loginNamestr,
          customhttpstate
        );
        localStorage.setItem(loginNamestr, setvalue);
      }
    }
  }
  initialization();
  $("#otherLink").find("li").remove();
  addotherlink("indexhtml");
});

$("#Cancel").click(function () {
  initialization();
});

$("#fullScreen").click(function () {
  initialization();
});
