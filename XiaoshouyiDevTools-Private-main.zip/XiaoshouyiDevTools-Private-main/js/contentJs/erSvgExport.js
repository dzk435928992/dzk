function erSvgExport (selRows, resultUrl) {
    if (selRows.length == 0) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '请选择要输出的对象！';
        return false;
    } else if (selRows.length > 50) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '选择对象个数不能大于50!';
        return false;
    }

    document.getElementById("over").style.display = "block";
    document.getElementById("layout").style.display = "block";
    let doFlag = [];
    let myuml = "";
    let myuml2 = "";
    let myuml3 = "";
    let map = new HashMap();
    let newMap1 = new HashMap();
    let newMap2 = new HashMap();
    var erCopyLimitData = [];
    selRows.forEach((Row) => {
        erCopyLimitData.push(Row.apiKey);
    });

    selRows.forEach((Row) => {
        myuml =
            'object "' +
            Row.label +
            "\\n(" +
            Row.apiKey +
            ')" as ' +
            Row.apiKey +
            "#0091d2\n";
        map.put(myuml, myuml);
        var headers = new Headers();
        fetch(resultUrl + "/rest/data/v2.0/xobjects/" + Row.apiKey + "/description",
            {
                headers,
                method: "GET",
            }
        )
            .then((response) => response.json())
            .then((result) => {
                if (result == undefined) {
                    return;
                }
                Object.keys(result["data"]["fields"]).forEach(function (record) {
                    if (result["data"]["fields"][record]["referTo"] == null) {
                        return;
                    }
                    if (result["data"]["fields"][record]["referTo"] != null && erCopyLimitData.indexOf(result["data"]["fields"][record]["referTo"]["apiKey"])==-1) {
                        return;
                    }
                    if (result["data"]["fields"][record]["apiKey"] == "ownerId") {
                        return;
                    }
                    if (result["data"]["fields"][record]["apiKey"] == "createdBy") {
                        return;
                    }
                    if (result["data"]["fields"][record]["apiKey"] == "updatedBy") {
                        return;
                    }
                    if (result["data"]["fields"][record]["apiKey"] == "entityType") {
                        return;
                    }
                    if (
                        result["data"]["fields"][record]["apiKey"] ==
                        "recentActivityCreatedBy"
                    ) {
                        return;
                    }

                    var referTo = result["data"]["fields"][record]["referTo"];
                    if (result["data"]["fields"][record]["type"] == 'detail') {
                        if (Row.apiKey == referTo["apiKey"]) {
                            return;
                        }
                        myuml2 = Row.apiKey + " }o-u- " + referTo["apiKey"] + "#ff0000\n";
                    } else {
                        if (Row.apiKey == referTo["apiKey"]) {
                            return;
                        }
                        myuml2 = Row.apiKey + " }o.u- " + referTo["apiKey"] + "\n";
                    }

                    if (newMap1.size() == 0) {
                        newMap1.put(myuml2, myuml2);
                    } else {
                        if (!newMap1.containsValue(myuml2)) {
                            newMap1.put(myuml2, myuml2);
                        }
                    }

                    myuml3 =
                        Row.apiKey +
                        " : " +
                        result["data"]["fields"][record]["apiKey"] +
                        "\n";

                    if (newMap2.size() == 0) {
                        newMap2.put(myuml3, myuml3);
                    } else {
                        if (!newMap2.containsValue(myuml3)) {
                            newMap2.put(myuml3, myuml3);
                        }
                    }

                });

                doFlag.push("done");

                if (selRows.length == doFlag.length) {
                    var value1 = newMap1.values();
                    for (var item in value1) {
                        map.put(value1[item], value1[item]);
                    }
                    var value2 = newMap2.values();
                    for (var item in value2) {
                        map.put(value2[item], value2[item]);
                    }

                    var values = map.values();
                    var endValue = 'title "销售易 ER图"\n';
                    for (var item3 in values) {
                        endValue += values[item3];
                    }
                    $("img.plantuml").attr("uml", endValue);
                    plantuml_runonce();

                    var deflater =
                        window.SharedWorker && new SharedWorker("rawdeflate.js");
                    if (deflater) {
                        deflater.port.addEventListener("message", done_deflating, false);
                        deflater.port.start();
                    } else if (window.Worker) {
                        deflater = new Worker("rawdeflate.js");
                        deflater.onmessage = done_deflating;
                    }

                    function done_deflating (e) {
                        var done = 0;
                        $("img").each(function () {
                            if (done == 1) return;
                            var u1 = $(this).attr("src");
                            if (u1 != null) return;
                            var u2 = $(this).attr("uml");
                            if (u2 == "") return;
                            $(this).attr("uml", "");

                            saveAs(
                                "https://www.plantuml.com/plantuml/svg/" + encode64(e.data),
                                "销售易-ERDs.svg"
                            );
                            done = 1;
                        });
                        plantuml_runonce();
                        document.getElementById("over").style.display = "none";
                        document.getElementById("layout").style.display = "none";
                    }
                    function plantuml_runonce () {
                        var done = 0;
                        $("img.plantuml").each(function () {
                            if (done == 1) return;
                            var u1 = $(this).attr("src");
                            if (u1 != null) return;
                            var u2 = $(this).attr("uml");
                            if (u2 == "") return;
                            var s = unescape(encodeURIComponent(u2));
                            if (deflater) {
                                if (deflater.port && deflater.port.postMessage) {
                                    deflater.port.postMessage(s);
                                } else {
                                    deflater.postMessage(s);
                                }
                            } else {
                                setTimeout(function () {
                                    done_deflating({
                                        data: deflate(s),
                                    });
                                }, 100);
                            }
                            done = 1;

                        });
                    }
                }
            });
    });
}