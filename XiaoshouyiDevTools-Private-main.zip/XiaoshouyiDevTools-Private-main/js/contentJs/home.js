var result;
var recordId;
var origin;
var belongId;
var belongId_listview;
var belongHash;
var eneityMap2 = [];
var standardCustomization;
var apiShowStatus;
var listviewCheckFlag; 
var finalHashStr;
var url;
var decryptKey = "A1B1C3D4S5G6H7P8";
var selectId = document.getElementById("sel2");
var objectChange = 'Add Login Link';
var selectHttpsId = document.getElementById("httpsSel");
var objecthttpChange = 'https://crm.xiaoshouyi.com';
var loginhtmlarr;
var state;
var eidtKey;
var hrefUrl;
var httpOldTime;

chrome.runtime.sendMessage({ XSYGetUrl: "url" }, function (response) {
    url = new URL(response.XSYUrl);
    origin = url.origin;
    result = url.pathname; 
    recordId = url.searchParams.get("id");
    belongId = url.searchParams.get("belongId");
    belongHash = url.hash;
    var startIndex = belongHash.lastIndexOf("/");
    var endIndex = belongHash.indexOf(".action");
    finalHashStr = belongHash.substring(startIndex + 1, endIndex);

    var startIndex = belongHash.indexOf("=");
    belongId_listview = belongHash.substring(startIndex + 1, startIndex.length); 
    addotherlink('homehtml');
    standardAndNonStandard();

});

function standardAndNonStandard() {
    var temp;
    var linkHeight = document.getElementById("otherLink").offsetHeight;
    if (recordId != null) { 
        document.getElementById("standardAndNonStandard").style.display = 'block';
        informationKey();
        load();
    } else {
        if (belongHash.indexOf("belongId") != -1) { 
            document.getElementById("standardAndNonStandard").style.display = 'block';
            tablesHeight = 366 + linkHeight;
            let messName = "tableHeight";
            let message = { "tablesHeight": tablesHeight };
            mess(messName, message);
            informationKey();
            load();
        } else { 
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers: {},
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data["data"]["records"].length; i++) {
                        if (data["data"]["records"][i].apiKey == finalHashStr) { 
                            temp = false;
                            document.getElementById("standardAndNonStandard").style.display = 'block';
                            tablesHeight = 366 + linkHeight;
                            let messName = "tableHeight";
                            let message = { "tablesHeight": tablesHeight };
                            mess(messName, message);
                            informationKey();
                            load();
                            break;
                        } else if (finalHashStr.substring(finalHashStr.indexOf('_') + 1) == data["data"]["records"][i].objectId) {
                            temp = false;
                            informationKey();
                            load();
                            document.getElementById("standardAndNonStandard").style.display = 'block';
                            tablesHeight = 366 + linkHeight;
                            let messName = "tableHeight";
                            let message = { "tablesHeight": tablesHeight };
                            mess(messName, message);
                            break;
                        }
                    }
                    if (temp != false) {
                        tablesHeight = 219 + linkHeight;
                        let messName = "tableHeight";
                        let message = { "tablesHeight": tablesHeight };
                        mess(messName, message);
                        load();
                        temp = "";
                    }
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        }
    }
}

$(function () {
    $("[data-toggle='tooltip']").tooltip();
    var hrefUrl = window.location.href;
    var url = new URL(hrefUrl);
    if (url.searchParams.get("showApiStatus") != null && url.searchParams.get("showApiStatus") != undefined) {
        if (url.searchParams.get("showApiStatus") === 'close') {
            $('#showObjAPIDiv').css("display", "none");
            $('#hideObjAPIDiv').css("display", "");
            apiShowStatus = 'close';
        }
    }
})

$('#showObjectAPI').click(function () {
    var objName = document.getElementById("objName").innerText;
    var objectLabel = objName.substring(0, objName.indexOf('('));
    var objectAPI = objName.substring(objName.indexOf('(') + 1, objName.indexOf(')'));
    var currentUserId = document.getElementById("tenent").innerText; 
    let messName = "showObjectAPI";
    let message = { "inputVal": objectLabel, "keyapi": objectAPI, "labelMap": currentUserId };
    mess(messName, message);
    $('#showObjAPIDiv').css("display", "none");
    $('#hideObjAPIDiv').css("display", "");
    apiShowStatus = 'close';
})

$('#hideObjectAPI').click(function () {
    var objName = document.getElementById("objName").innerText;
    var objectLabel = objName.substring(0, objName.indexOf('('));
    var objectAPI = objName.substring(objName.indexOf('(') + 1, objName.indexOf(')'));
    var currentUserId = document.getElementById("tenent").innerText;
    let messName = "closeObjectAPI";
    let message = { "inputVal": objectLabel, "keyapi": objectAPI, "labelMap": currentUserId };
    mess(messName, message);
    $('#hideObjAPIDiv').css("display", "none");
    $('#showObjAPIDiv').css("display", "");
    apiShowStatus = 'open';
})

function load() {
    if (recordId != null) {
        var linkHeight = document.getElementById("otherLink").offsetHeight;
        var detailsHeight = 407+linkHeight;
        let messName = "detailspageHeight";
        let message = { "detailHeight": detailsHeight };
        mess(messName, message);
        listviewCheckFlag = false;
        var str;
        if (url.searchParams.get("id") != null) {  
            if (url.searchParams.get("belongId") != null) {  
                var searchParam = new URLSearchParams(url.search);
                str = searchParam.get("belongId");
            } else {
                if (result.indexOf("final") != -1) {
                    str = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'))
                } else {
                    var str = url.pathname;
                    str = str.substring(1, str.indexOf("_"));
                }
            }

            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers: {},
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data["data"]["records"].length; i++) {
                        if (data["data"]["records"][i].objectId == str) {
                            standardCustomization = data["data"]["records"][i].apiKey
                        }
                        eneityMap2.push({
                            index: i + 1,
                            objectId: data["data"]["records"][i].objectId,
                            label: data["data"]["records"][i].label,
                            apiKey: data["data"]["records"][i].apiKey,
                        });
                    }
                    showobj(str);
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        } else {
            document.getElementById("showobjN").style.display = "none";
        }
    } else {
        listviewCheckFlag = true;
        $("#showObjAPIDiv").css("display", "none");
        if (belongHash.indexOf("belongId") != -1) {
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers: {},
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data["data"]["records"].length; i++) {
                        eneityMap2.push({
                            index: i + 1,
                            objectId: data["data"]["records"][i].objectId,
                            label: data["data"]["records"][i].label,
                            apiKey: data["data"]["records"][i].apiKey,
                        });
                    }
                    showobj(belongId_listview);
                })
                .catch((error) => {
                    console.error("Error:", error);
                });
        } else {
            if (finalHashStr.indexOf("standard_") != -1) {
                fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                    headers: {},
                    method: "GET",
                })
                    .then((response) => response.json())
                    .then((data) => {
                        for (var i = 0; i < data["data"]["records"].length; i++) {
                            if (finalHashStr.substring(finalHashStr.indexOf('_') + 1) == data["data"]["records"][i].objectId) { // entityKey.substring(entityKey.indexOf('_')+1) 标准自定义的ID
                                standardCustomization = data["data"]["records"][i].apiKey;
                                eneityMap2.push({
                                    index: i + 1,
                                    objectId: data["data"]["records"][i].objectId,
                                    label: data["data"]["records"][i].label,
                                    apiKey: data["data"]["records"][i].apiKey,
                                });
                                break;
                            }
                        }
                        showobj(standardCustomization);
                    })
                    .catch((error) => {
                        console.error("Error:", error);
                    });
            } else {
                fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                    headers: {},
                    method: "GET",
                })
                    .then((response) => response.json())
                    .then((data) => {
                        for (var i = 0; i < data["data"]["records"].length; i++) {
                            eneityMap2.push({
                                index: i + 1,
                                objectId: data["data"]["records"][i].objectId,
                                label: data["data"]["records"][i].label,
                                apiKey: data["data"]["records"][i].apiKey,
                            });
                        }
                        showobj(finalHashStr);
                    })
                    .catch((error) => {
                        console.error("Error:", error);
                    });
            }
        }
    }

    fetch(origin + "/rest/data/v2.0/social/user/actions/refer-user", {
        headers: {},
        method: "GET",
    })
        .then((response) => response.json())
        .then((data) => {
            var tanantId = data.result.tenantId
            var tenantName = data.result.tenantName;
            tenant(tanantId, tenantName);
        })
        .catch((error) => {
            console.error("Error:", error);
        });
}

function tenant(tenantId, tenantName) {
    var tenantFontSize = 'Tenant:' + tenantName + '(' + tenantId + ')'; 
    if (tenantFontSize.length < 32) {
        document.getElementById('tenent').innerHTML = 'Tenant: ' + tenantName + '(' + tenantId + ')';
    } else if (tenantFontSize.length >= 32 && tenantFontSize.length < 40) {
        document.getElementById('tenent').innerHTML = 'Tenant: ' + tenantName + '(' + tenantId + ')';
        document.getElementById('tenent').style.fontSize = 13;
    } else {
        document.getElementById('tenent').innerHTML = 'Tenant: ' + tenantName + '(' + tenantId + ')';
        $('#tenent').addClass("tennenCss");
    }
}

var showObjectAPITag = document.getElementById("showObjAPIDiv");
showObjectAPITag.onmouseover = function () {
    showObjectAPITag.className = "queryEditorbk";
}
showObjectAPITag.onmouseout = function () {
    showObjectAPITag.className = "queryEditor";
}

var closeObjectAPITag = document.getElementById("hideObjAPIDiv");
closeObjectAPITag.onmouseover = function () {
    closeObjectAPITag.className = "queryEditorbk";
}
closeObjectAPITag.onmouseout = function () {
    closeObjectAPITag.className = "queryEditor";
}

var queryEditorTag = document.getElementById("queryEditorEx");
queryEditorTag.onmouseover = function () {
    queryEditorTag.className = "queryEditorbk";
}
queryEditorTag.onmouseout = function () {
    queryEditorTag.className = "queryEditor";
}

var objectFieldTag = document.getElementById("objectField");
objectFieldTag.onmouseover = function () {
    objectFieldTag.className = "objectFieldbk";
}
objectFieldTag.onmouseout = function () {
    objectFieldTag.className = "objectField";
}

var objectFields = document.getElementById("ObjectFields");
objectFields.onmousemove = function () {
    objectFields.className = "objectFields";
}

objectFields.onmouseout = function () {
    objectFields.className = "exportFields";
}

function showobj(str) {
    for (var j = 0; j < eneityMap2.length; j++) {
        if (str == eneityMap2[j].objectId || str == eneityMap2[j].apiKey) {
            document.getElementById("objName").innerHTML =
                eneityMap2[j].label + "(" + eneityMap2[j].apiKey + ")";
        }
    }
}

$("#queryEditor").click(function () {
    var customizeApikey;
    if (listviewCheckFlag) {
        if (belongHash.indexOf("belongId") != -1) {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId_listview) {
                            customizeApikey = data.data.records[i].apiKey;
                            break;
                        }
                    }
                    tablesHeight = 900;
                    let messName = "indexCopyAndBackSingle";
                    let message = { "tablesHeight": tablesHeight };
                    mess(messName, message);
                    window.location.href =
                        "dataQuery.html?apiKey=" +
                        customizeApikey +
                        "&recordId=" +
                        recordId +
                        "&page=detailsPage" +
                        "&showApiStatus=" + apiShowStatus;
                });
        } else {
            if (finalHashStr.indexOf("standard_") != -1) {
                tablesHeight = 900;
                let messName = "indexCopyAndBackSingle";
                let message = { "tablesHeight": tablesHeight };
                mess(messName, message);
                window.location.href =
                    "dataQuery.html?apiKey=" + standardCustomization + "&recordId=" + null + "&page=detailsPage" +
                    "&showApiStatus=" + apiShowStatus;
            } else {
                tablesHeight = 900;
                let messName = "indexCopyAndBackSingle";
                let message = { "tablesHeight": tablesHeight };
                mess(messName, message);
                window.location.href =
                    "dataQuery.html?apiKey=" + finalHashStr + "&recordId=" + null + "&page=detailsPage" +
                    "&showApiStatus=" + apiShowStatus;
            }
        }
    } else {
        if (result != "/customize_detail.action") {
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') {  
                    var headers = new Headers();
                    fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                        headers,
                        method: "GET",
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            for (var i = 0; i < data.data.records.length; i++) {
                                if (data.data.records[i].objectId == belongId) {
                                    customizeApikey = data.data.records[i].apiKey;
                                    break;
                                }
                            }
                            tablesHeight = 900;
                            let messName = "indexCopyAndBackSingle";
                            let message = { "tablesHeight": tablesHeight };
                            mess(messName, message);
                            window.location.href =
                                "dataQuery.html?apiKey=" +
                                customizeApikey +
                                "&recordId=" + recordId +
                                "&page=detailsPage" +
                                "&showApiStatus=" + apiShowStatus;
                        });
                } else {
                    var apikey = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'));
                    tablesHeight = 900;
                    let messName = "indexCopyAndBackSingle";
                    let message = { "tablesHeight": tablesHeight };
                    mess(messName, message);
                    window.location.href =
                        "dataQuery.html?apiKey=" + apikey + "&recordId=" + recordId + "&page=detailsPage" + "&showApiStatus=" +
                        apiShowStatus;
                }
            } else {
                var apiKey = result.substring(1, result.indexOf("_"));
                tablesHeight = 900;
                let messName = "indexCopyAndBackSingle";
                let message = { "tablesHeight": tablesHeight };
                mess(messName, message);
                window.location.href =
                    "dataQuery.html?apiKey=" + apiKey + "&recordId=" + recordId + "&page=detailsPage" +
                    "&showApiStatus=" + apiShowStatus;
            }
        } else {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId) {
                            customizeApikey = data.data.records[i].apiKey;
                            break;
                        }
                    }
                    tablesHeight = 900;
                    let messName = "indexCopyAndBackSingle";
                    let message = { "tablesHeight": tablesHeight };
                    mess(messName, message);
                    window.location.href =
                        "dataQuery.html?apiKey=" +
                        customizeApikey +
                        "&recordId=" +
                        recordId +
                        "&page=detailsPage" +
                        "&showApiStatus=" + apiShowStatus;
                });
        }
    }
});

$("#objectField").click(function () {
    if (listviewCheckFlag) {
        if (belongHash.indexOf("belongId") != -1) {
            var customizeApikey;
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId_listview) {
                            customizeApikey = data.data.records[i].apiKey;
                            break;
                        }
                    }
                    let messName = "messqueryObject";
                    let message = { "queryObject": customizeApikey };
                    mess(messName, message);
                });
        } else {
            if (finalHashStr.indexOf("standard_") != -1) {
                let messName = "messqueryObject";
                let message = { "queryObject": standardCustomization };
                mess(messName, message);
            } else {
                let messName = "messqueryObject";
                let message = { "queryObject": finalHashStr };
                mess(messName, message);
            }
        }
    } else {
        var customizeApikey;
        if (result != "/customize_detail.action") {
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') { 
                    var headers = new Headers();
                    fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                        headers,
                        method: "GET",
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            for (var i = 0; i < data.data.records.length; i++) {
                                if (data.data.records[i].objectId == belongId) {
                                    customizeApikey = data.data.records[i].apiKey;
                                    break;
                                }
                            }
                            let messName = "messqueryObject";
                            let message = { "queryObject": customizeApikey };
                            mess(messName, message);
                        });
                } else {
                    var apikey = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'));
                    let messName = "messqueryObject";
                    let message = { "queryObject": apikey };
                    mess(messName, message);
                }
            } else {
                var apiKey = result.substring(1, result.indexOf("_"));
                let messName = "messqueryObject";
                let message = { "queryObject": apiKey };
                mess(messName, message);
            }
        } else {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET",
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId) {
                            customizeApikey = data.data.records[i].apiKey;
                            break;
                        }
                    }
                    let messName = "messqueryObject";
                    let message = { "queryObject": customizeApikey };
                    mess(messName, message);
                });
        }
    }
});

$("#searchObject").click(function () {
    tablesHeight = 900;
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": tablesHeight };
    mess(messName, message);
    window.location.href = 'objectList.html?showApiStatus=' + apiShowStatus;
})

$("#closebutton").click(function () {
    let messName = "closebutton";
    let message = {};
    mess(messName, message);
})

$("#listObject").click(function () {
    if (recordId != null) {
        if (result != '/customize_detail.action') { 
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') {  
                    window.open(origin + '/index.action#/spa/customize.action?belongId=' + belongId);
                } else {
                    var apiKeyss = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'));
                    window.open(origin + '/index.action#/spa/' + apiKeyss + '.action');
                }
            } else {
                var apiKeyList = result.substring(1, result.indexOf('_'));
                window.open(origin + '/index.action#/spa/' + apiKeyList + '.action');
            }
        } else {
            window.open(origin + '/index.action#/spa/customize.action?belongId=' + belongId);
        }
    } else {
        if (belongHash.indexOf("belongId") != -1) {
            window.open(origin + '/index.action#/spa/customize.action?belongId=' + belongId_listview);
        } else {
            window.open(origin + '/index.action#/spa/' + finalHashStr + '.action');
        }
    }
})

var standard; 
$("#setting").click(function () {
    if (recordId != null) {
        if (result != '/customize_detail.action') {
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') { 
                    if (detailkey.indexOf('__c') != -1) {
                        window.open(origin + '/bff/webadmin/object/customizeObjectDetail/' + belongId);
                    } else {
                        $('#exampleModal').modal('show');
                        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                        document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
                    }
                } else {
                    $('#exampleModal').modal('show');
                    document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                    document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
                }
            } else {
                $('#exampleModal').modal('show');
                document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
            }
        } else {
            if (!standard) {
                window.open(origin + '/bff/webadmin/object/customizeObjectDetail/' + belongId);
            } else {
                $('#exampleModal').modal('show');
                document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
            }
        }
    } else {
        if (belongHash.indexOf("belongId") != -1) {
            window.open(origin + '/bff/webadmin/object/customizeObjectDetail/' + belongId_listview);
        } else {
            $('#exampleModal').modal('show');
            document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
            document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
        }
    }
})

$("#downButton").click(function () {
    if ($("#downButton").attr("aria-expanded") == 'false') {
        document.getElementById("downNav").style.display = 'block';
        $("#downButton").attr("aria-expanded", "true");
    } else {
        $("#downButton").attr("aria-expanded", "false");
        document.getElementById("downNav").style.display = 'none';
    }
})

$("#refresh").click(function () {
    var objName = document.getElementById("objName").innerText;
    var objectLabel = objName.substring(0, objName.indexOf("("));
    var objectAPI = objName.substring(
        objName.indexOf("(") + 1,
        objName.indexOf(")")
    );
    var currentUserId = document.getElementById("tenent").innerText; 
    let messName = "closeAPIAndRefresh";
    let message = { "inputVal": objectLabel, "keyapi": objectAPI, "labelMap": currentUserId };
    mess(messName, message);
    window.location.reload();
    document.getElementById("refresh").className = 'fa fa-spinner';
})

$("#closebutton").click(function () {
    let messName = "closebutton";
    let message = {};
    mess(messName, message);
})

var selRows = [];
var detailkey;
function informationKey() {
    if (recordId != null) {
        if (result != '/customize_detail.action') { 
            var apiKeys;
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') { 
                    var headers = new Headers();
                    fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                        headers,
                        method: "GET"
                    })
                        .then((response) => response.json())
                        .then((data) => {
                            for (var i = 0; i < data.data.records.length; i++) {
                                if (data.data.records[i].objectId == belongId) {
                                    selRows[0] = data.data.records[i];
                                    detailkey = data.data.records[i].apiKey;
                                    break;
                                }
                            }
                        })
                } else {
                    apiKeys = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'));
                }
            } else {
                apiKeys = result.substring(1, result.indexOf('_'));
            }

            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET"
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].apiKey == apiKeys) {
                            selRows[0] = data.data.records[i];
                            break;
                        }
                    }
                })
        } else {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET"
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId) {
                            selRows[0] = data.data.records[i];
                            detailkey = data.data.records[i].apiKey;
                            if (detailkey.indexOf("__c") == -1) {
                                standard = true;
                            }
                            break;
                        }
                    }
                })
        }
    } else {
        if (belongHash.indexOf("belongId") != -1) {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET"
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].objectId == belongId_listview) {
                            selRows[0] = data.data.records[i];
                            detailkey = data.data.records[i].apiKey;
                            break;
                        }
                    }
                })
        } else {
            var headers = new Headers();
            fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
                headers,
                method: "GET"
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.records.length; i++) {
                        if (data.data.records[i].apiKey == finalHashStr) {
                            selRows[0] = data.data.records[i];
                            break;
                        } else 
                            if (data.data.records[i].objectId == finalHashStr.substring(finalHashStr.indexOf('_') + 1)) {
                                selRows[0] = data.data.records[i];
                                break;
                            }
                    }
                })
        }
    }
}

$("#ObjectFields").click(function () {
    var apiKey;
    if (recordId != null) {
        if (result != '/customize_detail.action') {
            if (result.indexOf('final') != -1) {
                if (belongId != null && belongId != '') {  
                    apiKey = standardCustomization;
                } else {
                    apiKey = result.substring(result.lastIndexOf('/') + 1, result.indexOf('.'));
                }
            } else {
                apiKey = result.substring(1, result.indexOf('_'));
            }
        } else {
            apiKey = detailkey;
        }
    } else {
        if (belongHash.indexOf("belongId") != -1) {
            apiKey = detailkey;
        } else {
            if (finalHashStr.indexOf("standard_") != -1) {
                apiKey = standardCustomization
            } else {
                apiKey = finalHashStr;
            }
        }
    }
    excelExport(selRows, origin, "home");
})


$("#httpsSel").on("change", function () {
    objecthttpChange = selectHttpsId.options[selectHttpsId.selectedIndex].value;
})

$("#sel2").on("change", function () {
    objectChange = selectId.options[selectId.selectedIndex].value;
    if (objectChange == 'Add Useful Link') {
        document.getElementById("loginLinkDiv").style.display = 'none';
        document.getElementById("userLinkDiv").style.display = '';
    } else {
        document.getElementById("loginLinkDiv").style.display = '';
        document.getElementById("userLinkDiv").style.display = 'none';
    }
})

$(document).on("click", "#backbutton", function () {
    document.getElementById("backbutton").style.display = 'none';
    var getselectOrganization = document.getElementById("selectOrganization");
    var backHeight = getselectOrganization.offsetHeight;
    getselectOrganization.style.display = 'none';
    document.getElementById("otherLink").style.display = '';
    var linkHeight = document.getElementById("otherLink").offsetHeight;
    if(backHeight > linkHeight - 24){
        tablesHeight = backHeight - linkHeight + 24;
        let messName = "deleteHeight";
        let message = { "deleteHeight": tablesHeight };
        mess(messName, message); 
    }
    getselectOrganization.innerHTML = '';
});

$(document).on("click", "#otherLink li", function () {
    var linkHeight = document.getElementById("otherLink").offsetHeight;
    if ($(this).attr('index') == 'userful') {
        window.open($(this).attr('className'), "_blank");
    } else {
        var pwd = CryptoJS.AES.decrypt($(this).attr('className'), decryptKey).toString(CryptoJS.enc.Utf8);
       if($(this).attr('index') != ''){
            posturlfun($(this).attr('index'), $(this).attr('indexOf'), pwd,linkHeight,'homehtml');
        }else{
            posturlfun(objecthttpChange, $(this).attr('indexOf'), pwd,linkHeight,'homehtml');
        }
    }
});

$(document).on("click", "#buttonDiv button", function (event) {
    event.stopPropagation();
    if ($(this).attr('class') == 'eidtbutton') {
        state = 'Edit';
        eidtKey = $(this).attr('id');
        httpOldTime = $(this).attr('oldTime');
        if ($(this).attr('index') == 'userful') {
            document.getElementById("urlname").value = $(this).attr('indexOf');
            document.getElementById("inputLink").value = $(this).attr('className');
            document.getElementById("UsefulLInk").selected = 'selected';
            objectChange = selectId.options[selectId.selectedIndex].value;
            document.getElementById("loginLinkDiv").style.display = 'none';
            document.getElementById("userLinkDiv").style.display = '';
        } else {
            document.getElementById("loginName").value = $(this).attr('indexOf');
            var pwd = CryptoJS.AES.decrypt($(this).attr('className'), decryptKey).toString(CryptoJS.enc.Utf8);
            document.getElementById("Password").value = pwd;
            document.getElementById("linkTitle").value = $(this).attr('customin');
            document.getElementById("loginLink").selected = 'selected';
            objectChange = selectId.options[selectId.selectedIndex].value;
            document.getElementById("loginLinkDiv").style.display = '';
            document.getElementById("userLinkDiv").style.display = 'none';
            document.getElementById($(this).attr('index')).selected = 'selected';
            objecthttpChange = selectHttpsId.options[selectHttpsId.selectedIndex].value;
        }
    } else if ($(this).attr('class') == 'delbutton') {
        var deletekey = $(this).attr('id');
        localStorage.removeItem(deletekey);
        $("#otherLink").find("li").remove();
        initialization();
        addotherlink('homehtml');
        deleteHeight = 27;
        let messName = "deleteHeight";
        let message = { "deleteHeight": deleteHeight };
        mess(messName, message);
    }
});


$(document).on("click", "#selectOrganization li", function () {
    var httpOther;
    if($(this).attr('index') != ''){
        httpOther = $(this).attr('index');
    } else {
       httpOther= objecthttpChange
    }
    var posturl = $(this).attr('indexOf');
    $.ajax({
        type: "POST",
        url: posturl + '/global/login-entry.action',
        data: {
            "tenantId": $(this).attr('Id'),
            "passport.id": $(this).attr('class'),
            "encryptionKey": $(this).attr('className'),
            "loginName": httpOther
        },
        success: function (str_response) {
            window.open(posturl);
        }
    })
})

$("#button").click(function () {
    state = 'Add';
    document.getElementById("otherLoginInput").style.display = 'none';
})
$("#save").click(function () {
    var uelnamestr;
    var loginNamestr;
    var uelname;
    var inputLink;
    var loginName;
    var password;
    var logintitle;
    if (objectChange == 'Add Useful Link') {
        uelname = document.getElementById("urlname").value;
        uelnamestr = 'userful__' + uelname;
        inputLink = document.getElementById("inputLink").value;
        if (!checkerror(uelname, inputLink, true, '')) {
            return false;
        }
    } else {
        loginName = document.getElementById("loginName").value;
        if(objecthttpChange != '') {
            loginNamestr = objecthttpChange + loginName;
        } else {
            objecthttpChange =  document.getElementById("otherLoginInput").value
            loginNamestr = objecthttpChange + loginName;
        }
        password = document.getElementById("Password").value;
        var paswE = CryptoJS.AES.encrypt(password, decryptKey).toString();
        logintitle = document.getElementById("linkTitle").value;      
        if (!checkerror(loginName, paswE, false, logintitle)) {
            return false;
        }
    }

    if (state == 'Add') {
        var httpTime = new Date();    
        var nowDate = httpTime.getTime(); 
        if(objectChange == 'Add Useful Link'){
            if(!ischeckrepeat(uelnamestr,true)){
                return false
            }
            var setvalue = getJasonStr('','','',uelname,inputLink,'userful',nowDate,uelnamestr);
            localStorage.setItem(uelnamestr, setvalue);
        }else{
            if(!ischeckrepeat(loginNamestr,false)){
                return false
            }
            var setvalue = getJasonStr(loginName,paswE,logintitle,uelname,inputLink,objecthttpChange,nowDate,loginNamestr);
            localStorage.setItem(loginNamestr, setvalue);
        }
    } else if (state == 'Edit') {
        if(objectChange == 'Add Useful Link'){
        if (uelnamestr == eidtKey) {
            var setvalue = getJasonStr('','','',uelname,inputLink,'userful',httpOldTime,uelnamestr);
            localStorage.setItem(uelnamestr, setvalue);
        }else{
            if(!ischeckrepeat(uelnamestr,true)){
                return false
            }
            localStorage.removeItem(eidtKey);
            var setvalue = getJasonStr('','','',uelname,inputLink,'userful',httpOldTime,uelnamestr);
            localStorage.setItem(uelnamestr, setvalue);
        }
        }else{
            if (loginNamestr == eidtKey) {
                var setvalue = getJasonStr(loginName,paswE,logintitle,uelname,inputLink,objecthttpChange,httpOldTime,loginNamestr);
                localStorage.setItem(loginNamestr, setvalue);
            }else{
                if(!ischeckrepeat(loginNamestr,false)){
                    return false
                }
                localStorage.removeItem(eidtKey);
                var setvalue = getJasonStr(loginName,paswE,logintitle,uelname,inputLink,objecthttpChange,httpOldTime,loginNamestr);
                localStorage.setItem(loginNamestr, setvalue);
            }
        }
    }
    initialization();
    $("#otherLink").find("li").remove();
    addotherlink('homehtml');
    if(state == 'Add'){
        tablesHeight = 27;
        let messName = "saveHeight";
        let message = { "saveHeight": tablesHeight };
        mess(messName, message);
    }
})

$("#Cancel").click(function () {
    initialization();
})
$("#fullScreen").click(function () {
    initialization();
})



