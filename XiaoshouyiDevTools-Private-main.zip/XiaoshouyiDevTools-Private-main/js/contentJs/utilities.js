function otherColFormatter (value, row, index) {
    if (row.apiKey == "entityType") {
        if (Array.isArray(value)) {
            var subEntityType = entityTypes.substring(0, entityTypes.lastIndexOf("") - 2);
            row.selectitem = subEntityType;
            var selectItems = row.selectitem;
            var thisValue = JSON.stringify(selectItems);
            return thisValue.replace(/"/g, "");
        }
    }
    if (Array.isArray(value)) {
        var selectItems = '';
        for (var i = 0; i < value.length; i++) {
            selectItems += value[i].label + ', ';
        }
        if (selectItems == '') {
            return "";
        } else {
            var selectItems = selectItems.substring(0, selectItems.lastIndexOf("") - 2)
            var thisValue = JSON.stringify(selectItems);
            return thisValue.replace(/"/g, "");
        }
    } else if ("object" == typeof (value) && value != null) {
        var referToVal = value.apiKey;
        var thisValue = JSON.stringify(referToVal);
        return thisValue.replace(/"/g, "");
    } else {
        var thisValue = JSON.stringify(value);
        if (thisValue == null || thisValue == '' || thisValue == 'null') {
            return "";
        } else {
            return thisValue.replace(/"/g, "");
        }
    }
}

function noListFormatter (value, row, index) {
    return index + 1;
}

function encode64 (data) {
    r = "";
    for (i = 0; i < data.length; i += 3) {
        if (i + 2 == data.length) {
            r += append3bytes(data.charCodeAt(i), data.charCodeAt(i + 1), 0);
        } else if (i + 1 == data.length) {
            r += append3bytes(data.charCodeAt(i), 0, 0);
        } else {
            r += append3bytes(data.charCodeAt(i), data.charCodeAt(i + 1), data.charCodeAt(i + 2));
        }
    }
    return r;
}

function append3bytes (b1, b2, b3) {
    c1 = b1 >> 2;
    c2 = ((b1 & 0x3) << 4) | (b2 >> 4);
    c3 = ((b2 & 0xF) << 2) | (b3 >> 6);
    c4 = b3 & 0x3F;
    r = "";
    r += encode6bit(c1 & 0x3F);
    r += encode6bit(c2 & 0x3F);
    r += encode6bit(c3 & 0x3F);
    r += encode6bit(c4 & 0x3F);
    return r;
}

function encode6bit (b) {
    if (b < 10) {
        return String.fromCharCode(48 + b);
    }
    b -= 10;
    if (b < 26) {
        return String.fromCharCode(65 + b);
    }
    b -= 26;
    if (b < 26) {
        return String.fromCharCode(97 + b);
    }
    b -= 26;
    if (b == 0) {
        return '-';
    }
    if (b == 1) {
        return '_';
    }
    return '?';
}

function dateTimeFormatter (unixTime) {
    if (unixTime == null || unixTime == '' || unixTime == 'null') {
        return "";
    }
    var type = "Y-M-D H:i:s";
    var date = new Date(unixTime); 
    var dateTime = "";
    dateTime += date.getFullYear() + type.substring(1, 2);
    dateTime += (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + type.substring(3, 4);
    dateTime += (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
    if (type.substring(5, 6)) {
        if (type.substring(5, 6).charCodeAt() > 255) {
            dateTime += type.substring(5, 6);
            if (type.substring(7, 8)) {
                dateTime += " " + (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours());
                if (type.substring(9, 10)) {
                    dateTime += type.substring(8, 9) + (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes());
                    if (type.substring(11, 12)) {
                        dateTime += type.substring(10, 11) + (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
                    }
                }
            }
        } else {
            dateTime += " " + (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours());
            if (type.substring(8, 9)) {
                dateTime += type.substring(7, 8) + (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes());
                if (type.substring(10, 11)) {
                    dateTime += type.substring(9, 10) + (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
                }
            }
        }
    }
    return dateTime;
}

function dateFormatter (unixTime) {
    if (unixTime == null || unixTime == '' || unixTime == 'null') {
        return "";
    }
    var type = "Y-m-d";
    var date = new Date(unixTime); 
    var dateTime = "";
    dateTime += date.getFullYear() + type.substring(1, 2);
    dateTime += (date.getMonth() + 1 < 10 ? '0' + (date.getMonth() + 1) : date.getMonth() + 1) + type.substring(3, 4);
    dateTime += (date.getDate() < 10 ? '0' + (date.getDate()) : date.getDate());
    if (type.substring(5, 6)) {
        if (type.substring(5, 6).charCodeAt() > 255) {
            dateTime += type.substring(5, 6);
            if (type.substring(7, 8)) {
                dateTime += " " + (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours());
                if (type.substring(9, 10)) {
                    dateTime += type.substring(8, 9) + (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes());
                    if (type.substring(11, 12)) {
                        dateTime += type.substring(10, 11) + (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
                    }
                }
            }
        } else {
            dateTime += " " + (date.getHours() < 10 ? '0' + (date.getHours()) : date.getHours());
            if (type.substring(8, 9)) {
                dateTime += type.substring(7, 8) + (date.getMinutes() < 10 ? '0' + (date.getMinutes()) : date.getMinutes());
                if (type.substring(10, 11)) {
                    dateTime += type.substring(9, 10) + (date.getSeconds() < 10 ? '0' + (date.getSeconds()) : date.getSeconds());
                }
            }
        }
    }
    return dateTime;
}

function timeFormatter (unixTime) {
    if (typeof (unixTime) != 'object') {
        if (unixTime == null || unixTime == '' || unixTime == 'null') {
            return "";
        }
        const date = new Date(unixTime);
        const hh = date.getHours();
        const mm = date.getMinutes();
        var time = "";
        if (hh < 10) {
            time = "0" + hh + "时";
        } else {
            time = hh + "时";
        }
        if (mm < 10) {
            time += "0" + mm + "分";
        } else {
            time += hh + "分";
        }
        return time;
    }
}

function doubleMonth (dou) {
    if (typeof (dou) != 'object') {
        if (dou == null) {
            return "";
        }
        return dou.toFixed(2);
    }
    return "";
}

function percentFormatter (percent, row, index, objectId) {
    if (typeof (percent) != 'object') {
        if (percent == null || percent == '' || percent == 'null') {
            return "0";
        }
        var value = percent * 100;
        return value + "%";
    }
    return "";
}

function otherFormatter (value, row, index, objectId) {
    if (typeof (value) != 'object') {
        if (value == null || value == '' || value == 'null') {
            return "";
        }
        return value;
    }
    return "";
}

function getImage (imageId, row, index, objectId) {
    if (imageId == null || imageId == '' || imageId == 'null') {
        return "";
    }
    return "<a href='#' >" + imageId[0].id + "</a>";
}

function getDoc (docId, row, index, objectId) {
    if (typeof (docId) != 'object') {
        if (docId == null || docId == '' || docId == 'null') {
            return "";
        }

        var myJson = JSON.parse(docId);
        return "<a href='#' >" + myJson[0].fileId + "</a>"
    }
    return "";
}

function getCurrentTabId () {
    return new Promise((resolve, reject) => {
        chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
            resolve(tabs.length ? tabs[0].id : null)
        });
    })
}

async function mess (messName, message) {
    const tabId = await getCurrentTabId()
    const connect = chrome.tabs.connect(tabId, { name: messName });
    connect.postMessage(message)
    connect.onMessage.addListener((mess) => {
    })
}

function formulaTextMat (value, row, index, objectId) {
    if (typeof (value) != 'object') {
        if (typeof (value)) {
            if (value == null || value == '' || value == 'null') {
                return "";
            }
            if (value.search("E") != -1) {
                let num = new Number(value);
                return num.toFixed(2);
            }
            return value;
        }
    }
    return "";
}

function HashMap () {
    var length = 0;
    var obj = new Object();
    this.isEmpty = function () {
        return length == 0;
    };
    this.containsKey = function (key) {
        return (key in obj);
    };
    this.containsValue = function (value) {
        for (var key in obj) {
            if (obj[key] == value) {
                return true;
            }
        }
        return false;
    };

    this.put = function (key, value) {
        if (!this.containsKey(key)) {
            length++;
        }
        obj[key] = value;
    };

    this.get = function (key) {
        return this.containsKey(key) ? obj[key] : null;
    };

    this.remove = function (key) {
        if (this.containsKey(key) && (delete obj[key])) {
            length--;
        }
    };

    this.values = function () {
        var _values = new Array();
        for (var key in obj) {
            _values.push(obj[key]);
        }
        return _values;
    };

    this.keySet = function () {
        var _keys = new Array();
        for (var key in obj) {
            _keys.push(key);
        }
        return _keys;
    };

    this.size = function () {
        return length;
    };

    this.clear = function () {
        length = 0;
        obj = new Object();
    };
}

function posturlfun(posturl,loginName,password,linkHeight,frompage){
    $.ajax({  
       type: "POST",  
       url: posturl+'/global/do-login.action',  
       data: {loginName :loginName,password:password},  
       success: function(result) {
            var resultobj = JSON.parse(result);
            if(resultobj.status == 202){
              issuccess = true;
              if(resultobj.data.companyList.length > 1){
                for(var i = 0; i < resultobj.data.companyList.length; i++){
                    if(document.getElementById("businessLogicCodeMouse") != null){
                        document.getElementById("businessLogicCodeMouse").style.display = 'none';
                    }
                    if(document.getElementById("modelJarMouse") != null){
                        document.getElementById("modelJarMouse").style.display = 'none';
                    }
                  document.getElementById("otherLink").style.display = 'none'
                  document.getElementById("backbutton").style.display = ''
                  var getselectOrganization =  document.getElementById("selectOrganization");
                  getselectOrganization.style.display = '';
                  getselectOrganization.innerHTML += "<li indexOf = '"+posturl+"' Id = '"+resultobj.data.companyList[i].id+"' class = '"+resultobj.data.userid+"' className = '"+resultobj.data.companyList[i].encryptionKey+"' index = '"+resultobj.data.username+"'>"+resultobj.data.companyList[i].name+"</li>";
                }

                if(frompage == 'homehtml' && getselectOrganization.offsetHeight > (linkHeight - 24)){
                    tablesHeight = getselectOrganization.offsetHeight - linkHeight + 74 +getselectOrganization.offsetTop;
                    let messName = "indexCopyAndBackSingle";
                    let message = { "tablesHeight": tablesHeight };
                    mess(messName, message); 
                }
              }else{
                $.ajax({  
                   type: "POST",  
                   url: posturl+'/global/login-entry.action',  
                   data: {
                            "tenantId":resultobj.data.companyList[0].id,
                            "passport.id":resultobj.data.userid,
                            "encryptionKey":resultobj.data.companyList[0].encryptionKey,
                            "loginName":resultobj.data.username
                          },
                   success: function(str_response) {
                    window.open(posturl);
                   }
                 })
              }
            }else if(resultobj.status == 0){
                window.open(posturl);
            }else{
              $('#exampleModal').modal('show');
              document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
              document.getElementById('modalbody').innerHTML = '登录失败，请检查用户名密码';
              return false;
            }
      }  
    });
}

function checkerror(uelname,inputLink,isuserful,logintitle,objecthttpChange,customhttpstate){
    if (uelname == '' || inputLink == '' ||(isuserful == false && logintitle == '')) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '请输入链接信息！';
        return false;
    }
    if (isuserful == true && inputLink.indexOf("https://") != 0 && inputLink.indexOf("http://") != 0) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '请输入链接信息！';
        return false;
    }
    if(customhttpstate && objecthttpChange.indexOf("https://") != 0 && objecthttpChange.indexOf("http://") != 0){
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '请输入链接信息！';
        return false;
    }
    return true
}

function ischeckrepeat(uelname,isuserful){
    if (localStorage.getItem(uelname)) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        if(isuserful){
            document.getElementById('modalbody').innerHTML = '输入链接名称重复！';
        }else{
            document.getElementById('modalbody').innerHTML = '同一环境下用户名已存在！';
        }
         return false;
    }else{
        return true;
    }
}

function getJasonStr(loginName,Password,title,linkname,userful,httpurl,httpTime,httpKey,customHttpLink){
    return '{"linkname":"'+linkname+'","loginName":"'+loginName+'","Password":"'+Password+'","title":"'+title+'","userful":"'+userful+'","httpurl":"'+httpurl+'","httpTime":"'+httpTime+'","httpKey":"'+httpKey+ '","customHttpLink":"'+customHttpLink+ '" }';
}

function addotherlink (nowpage) {
    let localStorageArr = [];
    for (var i = 0; i < localStorage.length; i++) {
        var name = localStorage.key(i);
        var getvalue = localStorage[name];
        var objvalue = JSON.parse(getvalue);
        localStorageArr.push(objvalue);
    }
    localStorageArr = localStorageArr.sort(compare("httpTime"));
    for(var i = 0; i < localStorageArr.length; i++){
        var objvalue = localStorageArr[i];
        var name = objvalue.httpKey;
        var organizationname = objvalue.httpurl;
        var httpTime = objvalue.httpTime;
        var customHttpLink = objvalue.customHttpLink;
        if(organizationname == 'userful'){
        var linkname = objvalue.linkname;
        var linkvalue = objvalue.userful;
        if(nowpage == 'indexhtml'){
            document.getElementById("otherLink").innerHTML += "<li class='otherlinkli' indexOf ='"+linkname+"' index ='"+organizationname+"' id ='"+name+"' className ='"+linkvalue+"'><a target='_blank' style='margin-left:10px;margin-top:6px;margin-right:5px;width:5%;float:left'><i class='fa fa-link' aria-hidden='true' style='text-align: center;width:20px;color: RGB(67, 181, 181);'></i></a> <div style = 'width:65%;float:left;overflow: hidden;text-overflow: ellipsis;'>" + linkname + "</div><div id = 'buttonDiv' style='float: right;'><button class = 'eidtbutton' customHttpLink = '"+customHttpLink+"' oldTime= '"+httpTime+"' indexOf = '"+linkname+"' index ='"+organizationname+"' id = '" + name + "' className = '" + linkvalue + "' data-toggle = 'modal' data-target='#modalTable'><i class='fa fa-pencil-square-o'></i></button><button class = 'delbutton' id = '" + name + "' className = '" + linkvalue + "'><i class='fa fa-trash-o'></i></button></div></li>";
        }else{
            document.getElementById("otherLink").innerHTML += "<li class='otherlinkli' indexOf ='"+linkname+"' index ='"+organizationname+"' id ='"+name+"' className ='"+linkvalue+"'><a target='_blank' style='margin-left:10px;margin-top:6px;margin-right:5px;width:5%;float:left'><i class='fa fa-link' aria-hidden='true' style='text-align: center;width:20px;color: RGB(67, 181, 181);'></i></a> <div style = 'width:65%;float:left;overflow: hidden;text-overflow: ellipsis;'>" + linkname + "</div></li>";
        }
        }else{
        var loginName = objvalue.loginName;
        var Password = objvalue.Password;
        var title = objvalue.title;
        if(nowpage == 'indexhtml'){
            document.getElementById("otherLink").innerHTML += "<li class='otherlinkli' indexOf ='"+loginName+"' index ='"+organizationname+"' id ='"+name+"' className ='"+Password+"'><a target='_blank' style='margin-left:10px;margin-top:6px;margin-right:5px;width:5%;float:left'><i class='fa fa-link' aria-hidden='true' style='text-align: center;width:20px;color: RGB(67, 181, 181);'></i></a> <div style = 'width:65%;float:left;overflow: hidden;text-overflow: ellipsis;'>" + title + "</div><div id = 'buttonDiv' style='float: right;'><button class = 'eidtbutton' customHttpLink = '"+customHttpLink+"' oldTime= '"+httpTime+"' customin = '"+title+"' indexOf = '"+loginName+"' index ='"+organizationname+"' id = '" + name + "' className = '" + Password + "' data-toggle = 'modal' data-target='#modalTable'><i class='fa fa-pencil-square-o'></i></button><button class = 'delbutton' id = '" + name + "' className = '" + Password + "'><i class='fa fa-trash-o'></i></button></div></li>";
        }else{
            document.getElementById("otherLink").innerHTML += "<li class='otherlinkli' indexOf ='"+loginName+"' index ='"+organizationname+"' id ='"+name+"' className ='"+Password+"'><a target='_blank' style='margin-left:10px;margin-top:6px;margin-right:5px;width:5%;float:left'><i class='fa fa-link' aria-hidden='true' style='text-align: center;width:20px;color: RGB(67, 181, 181);'></i></a> <div style = 'width:65%;float:left;overflow: hidden;text-overflow: ellipsis;'>" + title + "</div></li>";
        }
        }
    }
    if(nowpage == 'indexhtml' && localStorage.length < 10){
        for(var i=0;i < 10 - localStorage.length;i++){
            document.getElementById("otherLink").innerHTML +="<li style='height:25px;'></li>"
        }
    }
}

function compare(property) {
      return function (a, b) {
        var value1 = a[property];
        var value2 = b[property];
        return value1 - value2;
      }
}

function initialization(){
document.getElementById("loginLinkDiv").style.display = '';
document.getElementById("userLinkDiv").style.display = 'none';
document.getElementById("urlname").value = '';
document.getElementById("inputLink").value = '';
document.getElementById("loginLink").selected ='selected';
objectChange = selectId.options[selectId.selectedIndex].value;
document.getElementById("loginName").value = '';
document.getElementById("Password").value = '';
document.getElementById("linkTitle").value = '';
document.getElementById("https://crm.xiaoshouyi.com").selected ='selected';
objecthttpChange = 'https://crm.xiaoshouyi.com';
}

var flag;
$("#hideShow").click(function() {
    if(flag) {
        document.getElementById("Password").type = "password";
        document.getElementById("hideShow").src = "image/hide.png";
        flag = false;
    } else {
        document.getElementById("Password").type = "text";
        document.getElementById("hideShow").src = "image/show.png";
        flag = true;
    }

})