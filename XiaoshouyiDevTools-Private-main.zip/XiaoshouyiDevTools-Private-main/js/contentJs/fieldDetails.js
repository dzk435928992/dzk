var allObjectInfoDataArr = [];
var result;
var tableminwudth;
var allObjectInfoMap = new Map();
var nameMap = new Map();
var objectChange;
var queryLink;
var queryLinkApi;
var query = window.location.toString().substring(window.location.toString().indexOf('=') + 1);
var entityTypes = "";
chrome.runtime.sendMessage({ XSYGetUrl: "url" }, function (response) {
    var url = new URL(response.XSYUrl);
    result = url.origin;
    allObject(result);
    Loadapi(result);
});

$(function () {
    nameMap.set("label", "字段名称");
    nameMap.set("apiKey", "API名称");
    nameMap.set("type", "字段类型");
    nameMap.set("itemType", "项目类型");
    nameMap.set("defaultValue", "默认值");
    nameMap.set("required", "必填");
    nameMap.set("minLength", "最小长度");
    nameMap.set("maxLength", "最大长度");
    nameMap.set("encrypt", "加密存储");
})

function allObject (result) {
    $("#apikey").prepend(query);
    var headers = new Headers();
    fetch(result + "/rest/metadata/v2.0/xobjects/filter", {
        headers,
        method: "GET",
    })
        .then((response) => response.json())
        .then((data) => {
            allObjectInfoDataArr = data["data"]["records"];
             for (var i = 0; i < allObjectInfoDataArr.length; i++) {
                allObjectInfoMap.set(allObjectInfoDataArr[i].apiKey, allObjectInfoDataArr[i].objectId);
                let option = document.createElement("option");
                option.value = allObjectInfoDataArr[i].apiKey;
                option.innerHTML = allObjectInfoDataArr[i].label;
                if(allObjectInfoDataArr[i].apiKey.indexOf('__c') == -1){
                    document.getElementById("stanrdGroup").appendChild(option);  
                }else{
                    document.getElementById("customGroup").appendChild(option);  
                }
                if (query == allObjectInfoDataArr[i].apiKey) {
                    $('#SD_sobject-select').find("option[value = " + allObjectInfoDataArr[i].apiKey + "]").attr("selected", true);
                }
            }
            selectitemsType(result);
        })
        .catch((error) => {
            console.error("Error:", error);
        });

}

function selectitemsType (result) {
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + query + "/busiType", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            for (var i = 0; i < result.data.records.length; i++) {
                entityTypes += result.data.records[i].label + ", ";
            }
        });
    apiKayName(result);
}

function apiKayName (result) {
    $("#apikey").prepend(query);
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + query + "/description", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            if (query == result.data.apiKey) {
                var apiKeyName = result.data.label;
                queryLink = apiKeyName;
                queryLinkApi = result.data.apiKey;
                $("#apikeyName").prepend(apiKeyName);
            }
        });
    commonFetchObject(result, query);
}

function commonFetchObject (result, object) {
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + object + "/description", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            var objData = JSON.stringify(result['data']['fields']);
            objData = objData.replace(/\\"/g, "");
            var obJson = JSON.parse(objData);
            if (result['data']['fields'].length == 0) {
                $("#query_button").hide();
            } else {
                var jsonColumns = [];
                jsonColumns.push({ field: '', title: "<div>No.</div><div>#</div>", formatter: noListFormatter, class: 'overflowNo'});
                tableminwudth = 0;
                Object.keys(result['data']['fields'][0]).forEach(function (key) {
                    tableminwudth += 160;
                    if (key == 'label') {
                        jsonColumns.push({ field: key, title: "<div>" + nameMap.get(key) + "<div style='color:#909090;font-size:12px;'>" + key + "</div></div>", formatter: selectitemFormatters, class: 'overflow', sortable: true }); 
                    }
                });
                Object.keys(result['data']['fields'][0]).forEach(function (key) {
                    if (key == 'dependentPropertyName') {
                        return;
                    }
                    if (key == 'createable') {
                        return;
                    }
                    if (key == 'updateable') {
                        return;
                    }
                    if (key == 'sortable') {
                        return;
                    }
                    if (key == 'enabled') {
                        return;
                    }
                    if (key == 'checkitem') {
                        return;
                    } else if (key == 'result') {
                        return;
                    } else if (key == 'unique') {
                        return;
                    } else if (key == 'referTo') {
                        return;
                    } else if (key == 'selectitem') {
                        return;
                    } else if (key == 'label') {
                        return;
                    }
                    if (key == 'apiKey') {
                        jsonColumns.push({ field: key, title: "<div>" + nameMap.get(key) + "<div style='color:#909090;font-size:12px;'>" + key + "</div></div>", formatter: selectitemFormatters, class: 'overflow', sortable: true });
                    } else if (key == 'defaultValue') {
                        jsonColumns.push({ field: key, title: "<div>" + nameMap.get(key) + "<div style='color:#909090;font-size:12px;'>" + key + "</div></div>", formatter: defaultFormatter, class: 'overflow', sortable: true }); 
                    } else {
                        jsonColumns.push({ field: key, title: "<div>" + nameMap.get(key) + "<div style='color:#909090;font-size:12px;'>" + key + "</div></div>", formatter: otherColFormatter, class: 'overflow', sortable: true }); 
                    }

                });
            }
            $('#table_field').bootstrapTable('destroy');
            $('#table_field').bootstrapTable({
                data: obJson,
                editable: true,
                sortable: true,
                search: true,
                cache: false,
                contentType: 'application/x-www-form-urlencoded;charset=utf-8',
                resizable: true,
                paginationVAlign: 'top',
                paginationHAlign: 'left',
                paginationDetailHAlign: 'right',
                sortName: 'autoNumber',
                sortOrder: 'asc',
                striped: true,
                columns: jsonColumns
            })
            var row = $("#table_field thead tr th").length;
            var tr = $("#table_field thead tr th");
            for (i = 0; i < row; i++) {
                var td = tr.eq(i);
                if (td.text() == 'No.') {
                    td.append("<div>" + 'No.' + "<div style='color:#909090;font-size:12px;'>" + '#' + "</div></div>");
                }
                if (td.text() == 'label') {
                    td.append("<div>" + '&nbsp;&nbsp;&nbsp;字段名称' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbsp;&nbsp;label' + "</div></div>");
                }
                if (td.text() == 'apiKey') {
                    td.append("<div>" + '&nbsp;&nbsp;API名称' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbsp;apiKey' + "</div></div>");
                }
                if (td.text() == 'type') {
                    td.append("<div>" + '&nbsp;&nbsp字段类型' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbsptype' + "</div></div>");
                }
                if (td.text() == 'itemType') {
                    td.append("<div>" + '&nbsp;&nbsp项目类型' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbspitemType' + "</div></div>");
                }
                if (td.text() == 'defaultValue') {
                    td.append("<div>" + '&nbsp;&nbsp默认值' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbspdefaultValue' + "</div></div>");
                }
                if (td.text() == 'required') {
                    td.append("<div>" + '&nbsp;&nbsp必填' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbsprequired' + "</div></div>");
                }
                if (td.text() == 'minLength') {
                    td.append("<div>" + '&nbsp;&nbsp最小长度' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbspminLength' + "</div></div>");
                }
                if (td.text() == 'maxLength') {
                    td.append("<div>" + '&nbsp;&nbsp最大长度' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbspmaxLength' + "</div></div>");
                }
                if (td.text() == 'encrypt') {
                    td.append("<div>" + '&nbsp;&nbsp加密存储' + "<div style='color:#909090;font-size:12px;'>" + '&nbsp;&nbspencrypt' + "</div></div>");
                }
            }
        });
}

function defaultFormatter (value, row, index) {
    if (value == null || value == '' || value == 'null') {
        return "";
    } else {
        return value;
    }
}

function Loadapi (result) {
    var headers = new Headers();
    var entityTypes = [];
    fetch(result + "/rest/data/v2.0/xobjects/" + query + "/busiType", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            for (var i = 0; i < result.data.records.length; i++) {
                var num = i + 1;
                $("#apikeyTable tbody").append("<tr><td style='width: 5%; text-align: center;'>" + num + "</td><td>" + result.data.records[i].id + "</td><td>" + result.data.records[i].label + "</td></tr>")
                entityTypes.push({ id: result.data.records[i].id, label: result.data.records[i].label });
            }
        });
}

function selectitemFormatters (referToid, value, row) {
    if (referToid == null || referToid == '' || referToid == 'null') {
        return "";
    }
    if (queryLinkApi.indexOf('__c') != -1) {
        if (allObjectInfoMap.get(queryLinkApi) != null && allObjectInfoMap.get(queryLinkApi) != '' && allObjectInfoMap.get(queryLinkApi) != undefined) {
            return "<a href='" + result + "/bff/webadmin/object/customizeObjectDetail/" + allObjectInfoMap.get(queryLinkApi) + " ' target='_blank' style = 'text-decoration: none; '>" + referToid + "</a>"
        }
    } else {
        if (allObjectInfoMap.get(queryLinkApi) != null && allObjectInfoMap.get(queryLinkApi) != '' && allObjectInfoMap.get(queryLinkApi) != undefined) {
            return '<a href="#" style = "text-decoration: none;">' + referToid + '</a>';

        }
    }
}

$('#table_field').on('click-cell.bs.table', function (e, field, value, row, $element) {
    if (value == null || value == '' || value == 'null') {
        return;
    }
    if (queryLinkApi.indexOf('__c') == -1) {
        if (field == "label" || field == "apiKey") {
            $('#exampleModal').modal('show');
            document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
            document.getElementById('modalbody').innerHTML = '当前对象不支持此功能。';
            return false;
        }
    }
})

$("#shutbutton").click(e => {
    let messName = "shutFieldbutton";
    let message = {};
    mess(messName, message);
})

var statu = true;
$("#fullScreen").click(e => {
    let messName = "allfiledwidth";
    if (statu) {
        allfiled = 141;
        allHeight = 108;
        allTop = 1;
        let message = { "allfiled": allfiled, "allHeight": allHeight, "allTop": allTop };
        mess(messName, message);
        statu = false;
        document.getElementById("fullScreen").src = "image/narrow.png";
    } else {
        allfiled = 100;
        allHeight = 100;
        allTop = 4;
        let message = { "allfiled": allfiled, "allHeight": allHeight, "allTop": allTop };
        mess(messName, message);
        statu = true;
        document.getElementById("fullScreen").src = "image/fullsc.png";
    }
})


$("#SD_sobject-select").on("change", function () {
    var selectId = document.getElementById("SD_sobject-select");
    objectChange = selectId.options[selectId.selectedIndex].value;
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + objectChange + "/description", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            if (objectChange == result.data.apiKey) {
                var apiKeyName = result.data.label;
                queryLink = apiKeyName;
                queryLinkApi = result.data.apiKey;
                $("#apikeyName").prepend(apiKeyName);
            }
        });
    commonFetchObject(result, objectChange);
});