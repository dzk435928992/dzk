var tableVal = "";
var temps;
async function showObjectApiTag () {
    $(".xsy_su_info_list")
        .children("li")
        .each(function () {
            var self = $(this);
            var labelSelf = self.find("div:first");
            var apiSelf = self.find("div:eq(1)");
            var apiParam = apiSelf.attr("data-item-primary");
            if (apiParam.indexOf(".") != -1) {
                apiParam = apiParam.split(".")[1];
            }

            var apiTabsHtml = $("<span id='objApiShowTag'>    (" + apiParam + ")</span>");;
            labelSelf.append(apiTabsHtml);
        });
}

async function closeObjectApiTag () {
    $("span[id*=objApiShowTag]").remove();
}

chrome.runtime.onConnect.addListener((res) => {
    if (res.name === "showObjectAPI") {
        showObjectApiTag();
    }
    if (res.name === "closeObjectAPI") {
        closeObjectApiTag();
    }
    if (res.name === "closeAPIAndRefresh") {
        closeObjectApiTag();
        detailsPage();
    }
    if (res.name === 'myConnect') {
        res.onMessage.addListener(mess => {
            var hrefUrl = window.location.href;
            var url = new URL(hrefUrl);
            var url_Hash = url.hash;
            var startIndex = url_Hash.lastIndexOf("/");
            var endIndex = url_Hash.indexOf(".action");
            entityKey = url_Hash.substring(startIndex + 1, endIndex); 
            detailsPage();
        })
    }

    if (res.name === 'myConnectQuery') {
        res.onMessage.addListener(mess => {
            var inputVal = mess.inputVal;
            var keyapi = mess.keyapi;
            pageQuery(inputVal, keyapi);
        })
    }
    if (res.name === 'shutButton') {
        shutButton();
    }
    if (res.name === 'closebutton') {

        if (temps == "field") {
            shutFieldbutton(); 
            closebutton(); 
        } else if (temps == "query") {
            closebutton(); 
            shutButton(); 
        } else {
            closebutton(); 
        }

    }

    if (res.name === 'tableHeight') {
        res.onMessage.addListener(mess => {
            var tableheight = mess.tablesHeight;
            var ui = document.getElementById("iframeHeight");
            var movePageHeight = document.getElementById("cj_move_page"); 
            if (tableheight >= 720) {
                ui.style.height = "720px";
            } else {
                ui.style.height = tableheight + "px";
                movePageHeight.style.height = tableheight + "px"; 
            }
        })
    }
    if(res.name === 'saveHeight'){
        res.onMessage.addListener(mess => {
            var ui = document.getElementById("iframeHeight").offsetHeight;
            var saveHeight = mess.saveHeight + ui;
            var  iframeHeight= document.getElementById("iframeHeight");
            var movePageHeight = document.getElementById("cj_move_page"); 
            iframeHeight.style.height = saveHeight + "px";
            movePageHeight.style.height = saveHeight + "px";
        })
    }

    if(res.name === 'deleteHeight'){
        res.onMessage.addListener(mess => {
            var ui = document.getElementById("iframeHeight").offsetHeight;
           var deleteHeight =  ui - mess.deleteHeight;
           var  iframeHeight= document.getElementById("iframeHeight");
           var movePageHeight = document.getElementById("cj_move_page"); 
           iframeHeight.style.height = deleteHeight + "px";
            movePageHeight.style.height = deleteHeight + "px"; 
        })
    }

    if (res.name === 'indexCopyAndBackSingle') {
        res.onMessage.addListener(mess => {
            var tableheight = mess.tablesHeight;
            var ui = document.getElementById("iframeHeight");
            var movePageHeight = document.getElementById("cj_move_page");
            if (tableheight >= 720) {
                ui.style.height = "100%";
                movePageHeight.style.height = "100%";
            } else {
                var tableheightp = Math.round((tableheight / 720) * 100);
                ui.style.height = "100%";
                movePageHeight.style.height = tableheightp + "%";

            }
        })
    }

    if (res.name === 'messqueryObject') {
        res.onMessage.addListener(mess => {
            var queryField = mess.queryObject;
            fieldQuery(queryField);
        })
    }

    if (res.name === 'shutFieldbutton') {
        res.onMessage.addListener(mess => {
            shutFieldbutton();
        })
    }

    if (res.name === 'querysHeight') {
        res.onMessage.addListener(mess => {
            var queryWidth = mess.queryWidth;
            var queryHeight = mess.queryHeight;
            var homecontentTop = mess.homecontentTop;
            var homecontentLeft = mess.homecontentLeft;
            var ui = document.getElementById("queryId");
            var homecontentStyle = document.getElementById("homecontent");
            homecontentStyle.style.top = homecontentTop + "%";
            homecontentStyle.style.left = homecontentLeft + "%"
            ui.style.width = queryWidth + "%";
            ui.style.height = queryHeight + "%";
        })
    }

    if (res.name === 'allfiledwidth') {
        res.onMessage.addListener(mess => {
            var allfiled = mess.allfiled;
            var allHeight = mess.allHeight;
            var allTop = mess.allTop;
            var ui = document.getElementById("allfiledId");
            var fieldHomeStyle = document.getElementById("fieldHome");
            fieldHomeStyle.style.top = allTop + "%";
            ui.style.width = allfiled + "%";
            ui.style.height = allHeight + "%";
        })
    }

    if (res.name === 'detailspageHeight') {
        res.onMessage.addListener(mess => {
            var detailHeight = mess.detailHeight;
            var ui = document.getElementById("iframeHeight");
            var movePageHeight = document.getElementById("cj_move_page");
            ui.style.height = detailHeight + "px";
            movePageHeight.style.height = detailHeight + "px";
        })
    }
})

function closebutton () {
    $('#cj_move_page').css("display", "none");
}

function shutFieldbutton () {
    var fieldHome = document.getElementById("fieldHome");
    fieldHome.remove();
    temps = "";
}

function fieldQuery (queryField) {
    var fieldHome = $("#fieldHome").length;
    if (fieldHome > 0) { 
        var fieldHomes = document.getElementById("fieldHome");
        fieldHomes.remove();
        var r = chrome.runtime.id;
        var fieldPage = '<div id="fieldHome" class="fieldHome" style="position:absolute;left:2%;top:4%">' +
            '<iframe id="allfiledId" src="chrome-extension://' + r + '/fieldDetails.html?query=' + queryField + '" style="width:100%; height:100%; border: none"></iframe></div>';
        $('#homeBody').append(fieldPage);
        temps = 'field';

    } else {
        var openHomecontent = $("#homecontent").length;
        if (openHomecontent > 0) {  
            var _li = document.getElementById("homecontent");
            _li.remove(); 
            var r = chrome.runtime.id;
            var fieldPage = '<div id="fieldHome" class="fieldHome" style="position:absolute;left:2%;top:4%">' +
                '<iframe id="allfiledId" src="chrome-extension://' + r + '/fieldDetails.html?query=' + queryField + '" style="width:100%; height:100%; border: none"></iframe></div>';
            $('#homeBody').append(fieldPage);
        } else {
            var r = chrome.runtime.id;
            var fieldPage = '<div id="fieldHome" class="fieldHome" style="position:absolute;left:2%;top:4%">' +
                '<iframe id="allfiledId" src="chrome-extension://' + r + '/fieldDetails.html?query=' + queryField + '" style="width:100%; height:100%; border: none"></iframe></div>';
            $('#homeBody').append(fieldPage);
        }
        temps = 'field';
    }
}

function shutButton () {
    var _li = document.getElementById("homecontent");
    if (_li != "undefined") {
        _li.remove();
        temps = "";
    }
}

function pageQuery (inputVal, keyapi) {
    var openHomecontent = $("#homecontent").length;
    if (openHomecontent > 0) {  
        var _li = document.getElementById("homecontent");
        _li.remove(); 

        var r = chrome.runtime.id;
        var newPage = '<div id="homecontent" class="homecontent" style="position:absolute;left:6%;top:7%;height:83%;">' +
            '<iframe id = "queryId" src="chrome-extension://' + r + '/dataDetails.html?query=' + inputVal + '&apikey=' + keyapi + '" style="width:100%; height:100%;border: none"></iframe></div>';
        $('#homeBody').append(newPage);
    } else {
        var fieldHome = $("#fieldHome").length;
        if (fieldHome > 0) { 
            var fieldHomes = document.getElementById("fieldHome");
            fieldHomes.remove(); 

            var r = chrome.runtime.id;
            var newPage = '<div id="homecontent" class="homecontent" style="position:absolute;left:6%;top:7%;height:83%;">' +
                '<iframe id = "queryId" src="chrome-extension://' + r + '/dataDetails.html?query=' + inputVal + '&apikey=' + keyapi + '" style="width:100%; height:100%; border: none"></iframe></div>';

            $('#homeBody').append(newPage);
        } else {
            var r = chrome.runtime.id;
            var newPage = '<div id="homecontent" class="homecontent" style="position:absolute;left:6%;top:7%;height:83%;">' +
                '<iframe id = "queryId" src="chrome-extension://' + r + '/dataDetails.html?query=' + inputVal + '&apikey=' + keyapi + '" style="width:100%; height:100%; border: none"></iframe></div>';

            $('#homeBody').append(newPage);
        }
    }
    temps = 'query';
}

function createPage () {
    var openedSubPageCheck = $('#cj_move_page').length;
    if (openedSubPageCheck > 0) {
        $('#cj_move_page').css("display", "");
    } else {
        var r = chrome.runtime.id;
        var page = '<div id="cj_move_page"><iframe src="chrome-extension://' + r + '/objectList.html" id ="iframeHeight"></iframe></div>'
        $(top.document.body).prop('id', "homeBody");
        $('#homeBody').append(page);
    }
}

function detailsPage () {
    var apiShowTagNum = $("span[id*=objApiShowTag]").length;
    var openedSubPageCheck = $('#cj_move_page').length;
    if (openedSubPageCheck > 0) {
        var cjmovepageremove = document.getElementById("cj_move_page");
        cjmovepageremove.remove();
        var r = chrome.runtime.id;
        var page;
        if (apiShowTagNum > 0) {
            page = '<div id="cj_move_page" style ="height:257px"><iframe src="chrome-extension://' + r + '/home.html?showApiStatus=close" id ="iframeHeight" class = "iframeheight"></iframe></div>'
        } else {
            page = '<div id="cj_move_page" style ="height:257px"><iframe src="chrome-extension://' + r + '/home.html" id ="iframeHeight" class = "iframeheight"></iframe></div>'
        }
        $(top.document.body).prop('id', "homeBody");
        $('#homeBody').append(page);
    } else {
        var r = chrome.runtime.id;
        var page = '<div id="cj_move_page" style ="height:257px"><iframe src="chrome-extension://' + r + '/home.html" id ="iframeHeight" class = "iframeheight"></iframe></div>'
        $(top.document.body).prop('id', "homeBody");
        $('#homeBody').append(page);
    }
}

function navigate2HomeIndexPage () {
    var openedSubPageCheck = $('#cj_move_page').length;
    if (openedSubPageCheck > 0) {
        $('#cj_move_page').css("display", "");
    } else {
        var r = chrome.runtime.id;
        var page = '<div id="cj_move_page" style="height:219px"><iframe src="chrome-extension://' + r + '/home.html" id ="iframeHeight" class = "iframeheight" style="height:219px"></iframe></div>'
        $(top.document.body).prop('id', "homeBody");
        $('#homeBody').append(page);
    }
}








