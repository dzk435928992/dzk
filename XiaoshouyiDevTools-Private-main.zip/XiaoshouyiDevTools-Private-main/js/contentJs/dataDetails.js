var selectRows;
var tableminwudth;
const objectMaps = new Map();
var result;
var urlResult;
var NameMap = new Map();
chrome.runtime.sendMessage({ XSYGetUrl: "url" }, function (response) {
    var url = new URL(response.XSYUrl);
    result = url.origin;
    urlResult = result;
    allType(result);
});

function onLoadpage (result) {
    var headers = new Headers();
    const searchParams = new URLSearchParams(window.location.search);
    var query = searchParams.get('query').toUpperCase();
    query = encodeURIComponent(query);
    fetch(result + "/rest/data/v2/query?q=" + query, {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            if (result.result.records.length != 0) {
                var datalength = result.result.records.length;
                recordsLength.innerHTML = "Query Result - Total Rows: " + datalength + " (仅能显示查询结果的前100条,请添加条件进行筛选)";
                var jsonColumns = [];
                jsonColumns.push({ field: '', title: "<div id='editRow'>" + 'No.' + "<div style='color:#909090;font-size:14px;'>" + '#' + "</div></div>", formatter: noListFormatter, class: 'overflowNo' });
                tableminwudth = 0;
                selectRows = 0;
                Object.keys(result['result']['records'][0]).forEach(function (key, val) {
                    tableminwudth += 160;
                    selectRows += 1;
                    if (key == 'id') {
                        jsonColumns.push({ field: key, title: "<div id='editRow'>ID<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: formatterObjectId, class: 'overflow', sortable: true });
                    } else if (key == 'ownerId' || key == 'recentActivityCreatedBy') {
                        jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: formatterOwnerId, class: 'overflow', sortable: true });
                    } else if (key == 'entityType') {
                        jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: entityTypeFormatter, class: 'overflow', sortable: true });
                    } else if (key == 'leadId') {
                        jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: leadIdFormatter, class: 'overflow', sortable: true });
                    } else {
                        let type = apiKayTypeMap.get(key);
                        let itemType = itemTypeMap.get(key);
                        if (type == 'picklist') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: getPickList, class: 'overflow', sortable: true });
                        } else if (type == 'percent') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: percentFormatter, class: 'overflow', sortable: true });
                        } else if (type == 'dimension') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: dimdepartsFormatter, class: 'overflow', sortable: true });
                        } else if (type != 'float' && itemType == 'Double') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: doubleMonth, class: 'overflow', sortable: true });
                        } else if (type == 'datetime') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: dateTimeFormatter, class: 'overflow', sortable: true });
                        } else if (type == 'date') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: dateFormatter, class: 'overflow', sortable: true });
                        } else if (type == "reference" || type == "detail") {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: referenceFormatter, class: 'overflow', sortable: true });
                        } else if (type == "image") {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: getImage, class: 'overflow', sortable: true });
                        } else if (type == "doc") {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: getDoc, class: 'overflow', sortable: true });
                        } else if (type == 'time') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: timeFormatter, class: 'overflow', sortable: true });
                        } else if (type == 'multipicklist') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: multipickListFormatter, class: 'overflow', sortable: true });
                        } else if (type == 'formula_text') {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: formulaTextMat, class: 'overflow', sortable: true });
                        } else {
                            jsonColumns.push({ field: key, title: "<div id='editRow'>" + NameMap.get(key) + "<div style='color:#909090;font-size:14px;'>" + key + "</div></div>", formatter: otherFormatter, class: 'overflow', sortable: true });
                        }
                    }
                });
                var querytable = document.getElementById("table_query");
                querytable.setAttribute("style", "min-width:" + tableminwudth + "px;");
            }
            if (selectRows < 45) {
                $('#table_query').bootstrapTable({
                    data: result['result']['records'],
                    cache: false,
                    contentType: 'application/x-www-form-urlencoded;charset=utf-8',
                    sortName: 'id',
                    sortOrder: 'asc',
                    pageNumber: 1,
                    columns: jsonColumns,
                    search: true,
                    resizable: true,
                    showExport: true,
                    buttonsAlign: "right",
                    exportOptions: {
                        onCellHtmlData: DeilWithRow,
                        fileName: '数据导出',        
                        worksheetName: 'Sheet1',
                        tableName: 'table'
                    }
                })
            } else {
                $('#table_query').bootstrapTable({
                    data: result['result']['records'],
                    cache: false,
                    contentType: 'application/x-www-form-urlencoded;charset=utf-8',
                    sortName: 'id',
                    sortOrder: 'asc',
                    pageNumber: 1,
                    columns: jsonColumns,
                    loading: true,
                    search: true,
                    showExport: true,
                    buttonsAlign: "right",
                    exportOptions: {
                        onCellHtmlData: DeilWithRow,
                        fileName: '数据导出',      
                        worksheetName: 'Sheet1',
                        tableName: 'table'
                    }
                })
            }
        });
    document.getElementById("loading").style.display = "none";
}

function DeilWithRow (cell, row, col, data) {
    if (row == 0) {
        if (data.match(/id="editRow">(\S*)<div style="color:#909090;/) == null) {
            return data;
        }
        data = data.match(/id="editRow">(\S*)<div style="color:#909090;/)[1];
        return data;
    } else {
        return data;
    }
}

function multipickListFormatter (multipicklist, row, index, objectId) {
    if (multipicklist == null || multipicklist == '' || multipicklist == 'null') {
        return "";
    }
    var str = "";
    for (var m = 0; m < multipicklist.length; m++) {
        str += multListMap.get(objectId).get(multipicklist[m]) + "<span class='pickListColor'>(" + multipicklist[m] + ")</span>; ";
    }
    return str.slice(0, -2);
}

$('#table_query').on('click-cell.bs.table', function (e, field, value, row, $element) {
    let type = apiKayTypeMap.get(field);
    if (value == null || value == '' || value == 'null') {
        return;
    }
    if (type == "image") {
        let values = value[0].id;
        queryImageUrl(values);
    }
    if (type == "doc") {
        var myJson = JSON.parse(value);
        let values = myJson[0].fileId;
        queryDocUrl(values);
    }
})
async function queryImageUrl (values) {
    var headers = new Headers();
    await fetch(result + "/rest/file/v2.0/image/actions/files?fileIds=" + values + "&outType=1", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            var oA = document.createElement("a");    
            oA.href = urlResult + result[0].url;     
            oA.target = "_blank";
            oA.click();                    
        })
}

async function queryDocUrl (values) {
    var headers = new Headers();
    await fetch(result + "/rest/file/v2.0/file/actions/files?fileIds=" + values + "&outType=1", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            var oA = document.createElement("a");   
            oA.href = urlResult + result[0].url;    
            oA.target = "_blank";                   
            oA.click();                            
        })
}

var parenteApikay = [];
function referenceFormatter (referToid, row, index, objectId) {
    if (referToid == '' || referToid == null || referToid == 'null') {
        return '';
    }
    var objectTypes = apikayReferMap.get(objectId);
    if (objectId == 'saleStageId') {
        return stageMap.get(row.saleStageId) + "<span class='pickListColor'>(" + row.saleStageId + ")</span>";
    } else if (objectId == 'lostStageId') {
        return stageMap.get(row.lostStageId) + "<span class='pickListColor'>(" + row.lostStageId + ")</span>";
    } else {
        var name = refertoNameMap.get(referToid);
        if(name == undefined && objectTypes != "user") {
            return referToid;
        }
        if (objectId == "parentDepartId") {
            return name + "<span class='pickListColor'>(" + referToid + ")</span>";
        }
        if (objectId == 'priceId') {
            return "<a href='" + result + "/customize_detail.action?id=" + referToid + "&belongId=407&new_window_detail=true' target='_blank' style = 'text-decoration: none; ' >" + name + "</a><span class='pickListColor'>(" + referToid + ")</span>";
        }
        if (objectTypes.search("__c") != -1) {
            var str = belongIdMap.get(objectTypes);
            return "<a href='" + result + "/customize_detail.action?id=" + referToid + "&belongId=" + str + "&new_window_detail=true' target='_blank' style = 'text-decoration: none; '>" + name + "</a></a><span class='pickListColor'>(" + referToid + ")</span>";
        } else {
            if(objectTypes == "user") {
                if(referToid == "-101") {
                    return "系统默认账号" + "</a><span class='pickListColor'>(" + referToid + ")</span>";
                }
                return "<a href='" + result + "/final/user.action?id=" + referToid + "' target='_blank' style = 'text-decoration: none; '>" + name + "</a><span class='pickListColor'>(" + referToid + ")</span>";
            }
            return "<a href='" + result + "/" + objectTypes + "_detail.action?id=" + referToid + "&new_window_detail=true' target='_blank' style = 'text-decoration: none; '>" + name + "</a></a><span class='pickListColor'>(" + referToid + ")</span>";
        }
    }
}

function leadIdFormatter (leadid) {
    if (leadid == null || leadid == '' || leadid == 'null') {
        return "";
    }
    var name = refertoNameMap.get(leadid);
    return "<a href='" + result + "/lead_detail.action?id=" + leadid + "&new_window_detail=true' target='_blank' >" + name + "</a></a><span class='pickListColor'>(" + leadid + ")</span>";
}

function getPickList (pickListId, row, index, objectId) {
    if (pickListId == null || pickListId == '' || pickListId == 'null') {
        return "";
    }
    return pickListMap.get(objectId).get(pickListId) + "<span class='pickListColor'>(" + pickListId + ")</span>";

}

function dimdepartsFormatter (dimdepartId) {
    if (dimdepartId == null || dimdepartId == '' || dimdepartId == 'null') {
        return "";
    }
    return objectMaps.get(dimdepartId);
}
var apiKayTypeMap = new Map();
var apikayReferMap = new Map();
var labelMap = [];
const pickListMap = new Map();
const itemTypeMap = new Map();
const multListMap = new Map();
var stageMap = new Map();
var belongIdMap = new Map();
var dataIdMap = [];
var dataIdMap2 = [];
var refertoNameMap = new Map();
var ids = 0;

async function allType (result) {
    const searchParams = new URLSearchParams(window.location.search);
    var apikey = searchParams.get('apikey');
    let response = await fetch(result + "/rest/data/v2.0/xobjects/" + apikey + "/description");
    let data = await response.json();
    labelMap = data['data']['fields'];
    for (var i = 0; i < labelMap.length; i++) {
        if (labelMap[i].selectitem.length != 0) {
            const selectitemMap = new Map();
            var selectitemList = labelMap[i].selectitem
            for (let s = 0; s < selectitemList.length; s++) {
                selectitemMap.set(selectitemList[s].value, selectitemList[s].label);
            }
            pickListMap.set(labelMap[i].apiKey, selectitemMap);
        }

        if (labelMap[i].checkitem.length != 0) {
            const multListItemMap = new Map();
            var multListItemList = labelMap[i].checkitem;
            for (let m = 0; m < multListItemList.length; m++) {
                multListItemMap.set(multListItemList[m].value, multListItemList[m].label);
            }
            multListMap.set(labelMap[i].apiKey, multListItemMap);
        }

        apiKayTypeMap.set(labelMap[i].apiKey, labelMap[i].type);
        itemTypeMap.set(labelMap[i].apiKey, labelMap[i].itemType);
        NameMap.set(labelMap[i].apiKey, labelMap[i].label);
        if (labelMap[i].referTo != undefined) {
            var apikays = labelMap[i].apiKey;
            var refers = labelMap[i].referTo.apiKey;
            apikayReferMap.set(apikays, refers);
        }
    }

    var entitypeMap = [];
    var headers = new Headers();
    await fetch(result + "/rest/data/v2.0/xobjects/opportunity/busiType", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            for (var i = 0; i < result.data.records.length; i++) {
                entitypeMap.push({ id: result.data.records[i].id, apiKey: result.data.records[i].apiKey, label: result.data.records[i].label });
            }
        })

        for (var key in entitypeMap) {
            fetch(result + "/rest/data/v2.0/xobjects/stage/actions/getStageListByEntityTypeApiKey", {
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    "data": {
                        'entityTypeApiKey': entitypeMap[key].apiKey
                    }
                }),
                method: 'post'
            })
                .then((response) => response.json())
                .then((data) => {
                    for (var i = 0; i < data.data.length; i++) {
                        stageMap.set(data.data[i].id, data.data[i].stageName);
                    }
                })
        }

    var headers = new Headers();
    await fetch(result + "/rest/metadata/v2.0/xobjects/filter", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            for (var i = 0; i < result.data.records.length; i++) {
                belongIdMap.set(result.data.records[i].apiKey, result.data.records[i].objectId);
            }
        })

    var headers = new Headers();
    var query = searchParams.get('query').toUpperCase();
    query = encodeURIComponent(query);
    await fetch(result + "/rest/data/v2/query?q=" + query, {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            Object.keys(result['result']['records'][0]).forEach(function (key, val) {
                ids = 0;
                let type = apiKayTypeMap.get(key);
                if (type == "reference" || type == "detail" || type == "owner") {
                    objectTypes = apikayReferMap.get(key);
                    var str = "";
                    var str2 = "";
                    for (var i = 0; i < result.result.records.length; i++) {
                        if (result.result.records[i][key] != null) {
                            if (str.search(result.result.records[i][key]) == -1) {
                                if (ids >= 55) {
                                    str2 += result.result.records[i][key] + ",";
                                } else {
                                    str += result.result.records[i][key] + ",";
                                }
                                ids++;
                            }
                        }
                    }
                    str = str.slice(0, -1);
                    dataIdMap.push({ objApikey: objectTypes, dataIds: str });
                    if (ids >= 55) {
                        str2 = str2.slice(0, -1);
                        dataIdMap2.push({ objApikey: objectTypes, dataIds: str2 });
                    }
                }
            });

            for (var i = 0; i < dataIdMap.length; i++) {
                var objApikeyName = "name";
                var apikeyName = dataIdMap[i].objApikey;
                if (dataIdMap[i].objApikey == "account" || dataIdMap[i].objApikey == "opportunity" || dataIdMap[i].objApikey == "contact" || dataIdMap[i].objApikey == "parduct" || dataIdMap[i].objApikey == "campaign" || dataIdMap[i].objApikey == "task" || dataIdMap[i].objApikey == "product" || dataIdMap[i].objApikey == "terminal") {
                    objApikeyName = dataIdMap[i].objApikey + "Name";
                }
                if(dataIdMap[i].objApikey == "expenseaccount") {
                    objApikeyName = "title";
                }
                if (dataIdMap[i].objApikey == "department") {
                    objApikeyName = "departName";
                }
                if (dataIdMap[i].objApikey == "contract") {
                    objApikeyName = "contractCode";
                }
                var sql = "select id, " + objApikeyName + " from " + dataIdMap[i].objApikey + " where id in(" + dataIdMap[i].dataIds + ")";
                queryData(sql, apikeyName);
            }
            
            if (dataIdMap2.length > 0) {
                for (var i = 0; i < dataIdMap2.length; i++) {
                    var objApikeyName = "name";
                    var apikeyName = dataIdMap2[i].objApikey;
                    if (dataIdMap2[i].objApikey == "account" || dataIdMap2[i].objApikey == "opportunity" || dataIdMap2[i].objApikey == "contact" || dataIdMap2[i].objApikey == "parduct" || dataIdMap[i].objApikey == "campaign") {
                        objApikeyName = dataIdMap2[i].objApikey + "Name";
                    }
                    if (dataIdMap2[i].objApikey == "contract") {
                        objApikeyName = "contractCode";
                    }
                    var sql = "select id, " + objApikeyName + " from " + dataIdMap2[i].objApikey + " where id in(" + dataIdMap2[i].dataIds + ")";
                    queryData(sql, apikeyName);
                }
            }
        })
        entityTypeFor();
}

function queryData (sql, apikeyName) {
    fetch(result + "/rest/data/v2/query?q=" + sql, {
        headers: {},
        method: "GET"
    })
        .then((response) => response.json())
        .then((data) => {
            if (data.code == "200") {
                if (data.result.records.length > 0) {
                    for (var i = 0; i < data.result.records.length; i++) {
                        if (apikeyName == "account" || apikeyName == "terminal") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].accountName);
                        } else if (apikeyName == "contract") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].contractCode);
                        } else if (apikeyName == "task") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].taskName);
                        } else if (apikeyName == "opportunity") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].opportunityName);
                        } else if (apikeyName == "contact") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].contactName);
                        } else if (apikeyName == "campaign") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].campaignName);
                        } else if (apikeyName == "department") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].departName);
                        } else if (apikeyName == "expenseaccount") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].title);
                        } else if (apikeyName == "product") {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].productName);
                        } else {
                            refertoNameMap.set(data.result.records[i].id, data.result.records[i].name);
                        }
                    }
                }
            }
        })
}

function entityTypeFormatter (value) {
    var entityLabel = entityTypeDataMap.get(value);
    var thisValue = JSON.stringify(entityLabel);
    if (entityLabel == null || entityLabel == 'undefined') {
        return "";
    }
    return thisValue.replace(/"/g, "");
}

var entityTypeDataMap = new Map();
function entityTypeFor () {
    const searchParams = new URLSearchParams(window.location.search);
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + searchParams.get('apikey') + "/busiType", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            for (var i = 0; i < result.data.records.length; i++) {
                entityTypeDataMap.set(result.data.records[i].id, result.data.records[i].label);
            }
        })
        .then(val => {
            fetch(result + "/rest/data/v2/query?q=SELECT Id,departName From department", {
                headers,
                method: "GET"
            })
                .then((response) => response.json())
                .then((result) => {
                    for (var s = 0; s < result.result.records.length; s++) {
                        objectMaps.set(result.result.records[s].id, result.result.records[s].departName);
                    }
                })
                .then(val => {
                    setTimeout(() => {
                        onLoadpage(result);
                    }, 500);
                })

        })

}

function formatterOwnerId (ownerIdVal) {
    if (ownerIdVal != null) {
        var name = refertoNameMap.get(ownerIdVal);
        if(name == undefined) {
            return ownerIdVal;
        }
        return "<a href='" + result + "/final/user.action?id=" + ownerIdVal + "' target='_blank' style = 'text-decoration: none; '>" + name + "</a><span class='pickListColor'>(" + ownerIdVal + ")</span>";
    }
    return "";
}

function formatterObjectId (objectId) {
    const searchParams = new URLSearchParams(window.location.search);
    var str = belongIdMap.get(searchParams.get('apikey'));
    if (searchParams.get('apikey').search("__c") != -1) {
        return "<a href='" + result + "/customize_detail.action?id=" + objectId + "&belongId=" + str + "&new_window_detail=true' target='_blank' style = 'text-decoration: none; '>" + objectId + "</a>";
    } else {
        return "<a href='" + result + "/" + searchParams.get('apikey') + "_detail.action?id=" + objectId + "&new_window_detail=true' target='_blank' style = 'text-decoration: none; '>" + objectId + "</a>";
    }
}
$("#shutButton").click(e => {
    document.getElementById('table_query').value = '';
    let messName = "shutButton";
    let message = {};
    mess(messName, message);
})

var statu = true;
$("#fullScreen").click(e => {
    if (statu) {
        var bodyHeight = document.getElementsByClassName("fixed-table-body");
        for (var i = 0; i < bodyHeight.length; i++) {
            bodyHeight[i].style.height = "745px";
        }
        var footTop = document.getElementsByClassName("fixed-table-pagination");
        for (var a = 0; a < footTop.length; a++) {
            footTop[a].style.cssText = "margin-top: -3px;";
        }
        queryWidth = 140;
        queryHeight = 113;
        homecontentTop = 1;
        homecontentLeft = 4;
        let messName = "querysHeight";
        let message = { "queryWidth": queryWidth, "queryHeight": queryHeight, "homecontentTop": homecontentTop, "homecontentLeft": homecontentLeft };
        mess(messName, message);

        statu = false;
        document.getElementById("fullScreen").src = "image/narrow.png";
    } else {
        var bodyHeight = document.getElementsByClassName("fixed-table-body");
        for (var i = 0; i < bodyHeight.length; i++) {
            bodyHeight[i].style.height = "567px";
        }
        var footTop = document.getElementsByClassName("fixed-table-pagination");
        for (var a = 0; a < footTop.length; a++) {
            footTop[a].style.cssText = "margin-top: 0px;";
        }
        queryWidth = 100;
        queryHeight = 100;
        homecontentTop = 10;
        homecontentLeft = 6;
        let messName = "querysHeight";
        let message = { "queryWidth": queryWidth, "queryHeight": queryHeight, "homecontentTop": homecontentTop, "homecontentLeft": homecontentLeft };
        mess(messName, message);
        statu = true;
        document.getElementById("fullScreen").src = "image/fullsc.png";
    }


})