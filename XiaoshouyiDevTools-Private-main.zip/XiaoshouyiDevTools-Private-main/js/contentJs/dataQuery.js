var dataLableMap = [];
var selRows = [];
var result;
var url;
var editor;
var recordId;
chrome.runtime.sendMessage({ XSYGetUrl: "url" }, function (response) {
    url = new URL(response.XSYUrl);
    result = url.origin;
    editor = ace.edit("inputSql");
    editor.session.setMode("ace/mode/sql");
    editor.setTheme("ace/theme/eclipse");
    document.getElementById('inputSql').style.fontSize = '14px';
    editor.session.setUseWrapMode(true);
    onLoads(result);
});

function onLoads (result) {
    var hrefUrl = window.location.href;
    url = new URL(hrefUrl);
    recordId = url.searchParams
    if (recordId.get('recordId') == null || recordId.get('recordId') == "null") {
        editor.setValue("select Id from " + recordId.get('apiKey'));
    } else {
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey') + " where id =" + recordId.get('recordId'));
    }
    var headers = new Headers();
    fetch(result + "/rest/data/v2.0/xobjects/" + recordId.get('apiKey') + "/description", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            console.log('data***********' +JSON.stringify(result['data']['fields']));
            if (result['data']['fields'].length == 0) {
                var tips = document.getElementById("Tips");
                tips.style.display = "block";
                $("#query_button").hide();
            } else {
                var jsonColumns = [];
                jsonColumns.push({
                    checkbox: true,
                    class: "checkbox-col",
                });
                Object.keys(result['data']['fields'][0]).forEach(function (key) {

                    if (key == 'dependentPropertyName') {
                        return;
                    }
                    if (key == 'createable') {
                        return;
                    }
                    if (key == 'updateable') {
                        return;
                    }
                    if (key == 'sortable') {
                        return;
                    }
                    if (key == 'enabled') {
                        return;
                    }
                    if (key == 'checkitem') {
                        return;
                    }
                    if (key == 'label') {
                        jsonColumns.push({ field: key, title: key, formatter: rearrange });
                    } else if (key == "type") {
                        jsonColumns.push({ field: key, title: key });
                    }
                });
            }

            $('#table_single').bootstrapTable('destroy');
            $('#table_single').bootstrapTable({
                data: result['data']['fields'],
                editable: true,
                pagination: false,
                search: true,
                buttonsAlign: "left",
                paginationVAlign: 'top',
                paginationHAlign: 'left',
                paginationDetailHAlign: 'right',
                sortName: 'autoNumber',
                sortOrder: 'asc',
                columns: jsonColumns
            })
        });

    var tablesHeight = 0;
    tablesHeight = 900
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": tablesHeight };
    mess(messName, message);
}

function rearrange (value, row, index) {
    return "<div style='font-size:14px;'>" + row.label + "<div style='color:#909090;font-size:12px;'>" + row.apiKey + "</div></div>";
}

var apikey = "";
$('#table_single').on('check.bs.table', function (e, row, $element) {
    apikey += ", " + JSON.parse(JSON.stringify(row)).apiKey;
    var editorValue = editor.getValue();
    editorValueWhere = editorValue.substring(editorValue.indexOf(' where '),editorValue.length);
    if(editorValue.indexOf(' where ') != -1){
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey') + editorValueWhere);
    }else if(editorValue.indexOf(' where') == editorValue.length - 6){
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey') + ' where');
    }else{
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey'));
    }
});

$('#table_single').on('uncheck.bs.table', function (e, row, $element) {
    var uncheckApi = editor.getValue();
    var uncheckApikey = JSON.parse(JSON.stringify(row)).apiKey;
    editor.setValue(uncheckApi.replace(", " + uncheckApikey, ""));
    apikey = apikey.replace(", " + uncheckApikey, "");
});

$('#table_single').on('check-all.bs.table', function (e, rowsAfter, rowsBefore) {
    apikey = "";
    var rowNum = JSON.parse(JSON.stringify(rowsAfter)).length;
    for (var i = 0; i < rowNum; i++) {
        apikey += ", " + JSON.parse(JSON.stringify(rowsAfter))[i].apiKey;
    }
    var editorValue = editor.getValue();
    editorValueWhere = editorValue.substring(editorValue.indexOf(' where '),editorValue.length);
    if(editorValue.indexOf(' where ') != -1){
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey') + editorValueWhere);
    }else if(editorValue.indexOf(' where') == editorValue.length - 6){
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey') + ' where');
    }else{
        editor.setValue("select id" + apikey + " from " + recordId.get('apiKey'));
    }
});

$('#table_single').on('uncheck-all.bs.table', function (e, rowsAfter, rowsBefore) {
    var editorValue = editor.getValue();
    editorValueWhere = editorValue.substring(editorValue.indexOf(' where '),editorValue.length);
    if(editorValue.indexOf(' where ') != -1){
        editor.setValue("select id from " + recordId.get('apiKey') + editorValueWhere);
    }else if(editorValue.indexOf(' where') == editorValue.length - 6){
        editor.setValue("select id from " + recordId.get('apiKey') + ' where');
    }else{
        editor.setValue("select id from " + recordId.get('apiKey'));
    }
    apikey = "";
});

$("#query_button").click(e => {
    var query = window.location.toString().substring(window.location.toString().indexOf('=') + 1);
    var inputVal = editor.getValue();
    if (query.substring(0, 6) == 'order&') {
        inputVal = inputVal.toUpperCase();
        var fromOrder = 'from order';
        inputVal = inputVal.replace(fromOrder.toUpperCase(), 'from _order');
    }
    inputVal = encodeURIComponent(inputVal);

    fetch(result + "/rest/data/v2/query?q=" + inputVal, {
        headers: {},
        method: "GET"
    })
        .then((response) => response.json())
        .then((result) => {
            if (result.code == "200") {
                if (result.result.records.length != 0) {
                    let message = { "inputVal": inputVal, "keyapi": query };
                    let messName = "myConnectQuery";
                    mess(messName, message);
                } else {
                    $('#exampleModal').modal('show');
                    document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                    document.getElementById('modalbody').innerHTML = '查询结果为空！';
                }
            } else {
                if(inputVal.search("compVisitObject") != -1) {
                    $('#exampleModal').modal('show');
                    document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
                    document.getElementById('modalbody').innerHTML = '不支持查询compvisitobject、compVisitObject_compound、compVisitObject_data字段！';
                } else {
                    $('#exampleModal').modal('show');
                    document.getElementById('exampleModalLabel').innerHTML = '警告';
                    document.getElementById('modalbody').innerHTML = 'SQL文出错！<br>' + "errorMsg: " + result.msg;
                }
            }
        });
});

$("#prevPage").click(function () {
    var url_Location = window.location.search.substring();
    var hrefUrl = window.location.href;
    url = new URL(hrefUrl);
    var searchParam = url.searchParams;
    var apiUrlParam;
    if (searchParam.get('showApiStatus') != null && searchParam.get('showApiStatus') != undefined) {
        apiUrlParam = searchParam.get('showApiStatus');
    } else {
        apiUrlParam = null;
    }
    var url_InputValue = url_Location.substring(url_Location.indexOf('inputValue=') + 11, url_Location.length)
    if (url_Location.indexOf('&page=indexCopy') != -1) {
        location.href = "objectList.html?showApiStatus=" + apiUrlParam + "&inputValue=" + url_InputValue;
    } else if (url_Location.indexOf('&page=detailsPage') != -1) {
        var tablesHeight = 0;
        tablesHeight = 400
        let messName = "tableHeight";
        let message = { "tablesHeight": tablesHeight };
        mess(messName, message);
        location.href = "home.html?showApiStatus=" + apiUrlParam;
    }
})

$("#closebuttonSingle").click(function () {
    let messName = "closebutton";
    let message = {};
    mess(messName, message);
})

$("#fieldButton").click(function () {
    if ($("#fieldButton").attr("aria-expanded") == 'false') {
        document.getElementById("downAll").style.display = 'block';
        $("#fieldButton").attr("aria-expanded", "true");
    } else {
        $("#fieldButton").attr("aria-expanded", "false");
        document.getElementById("downAll").style.display = 'none';
    }
})

function informationKeys () {
    var headers = new Headers();
    fetch(origin + "/rest/metadata/v2.0/xobjects/filter", {
        headers,
        method: "GET"
    })
        .then((response) => response.json())
        .then((data) => {
            for (var i = 0; i < data.data.records.length; i++) {
                if (data.data.records[i].apiKey == recordId.get('apiKey')) {
                    selRows[0] = data.data.records[i];
                    break;
                }
            }
        })
}
