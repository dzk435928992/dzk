var allObjectInfoDataArr = [];
var url_Location = window.location.search.substring();
var url_InputValue = url_Location.substring(url_Location.indexOf('inputValue=') + 11, url_Location.length);
url_InputValue = decodeURIComponent(url_InputValue);
var apiUrlParam;
var results;
var resultUrl;
chrome.runtime.sendMessage({ XSYGetUrl: "url" }, function (response) {
    var url = new URL(response.XSYUrl);
    resultUrl = url;
    results = url.origin;
    onLoad(results);
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": 900 };
    mess(messName, message);
});

$(function () {
    var hrefUrl = window.location.href;
    var url = new URL(hrefUrl);
    if (url.searchParams.get("inputValue") == null || url.searchParams.get("inputValue") == undefined || url.searchParams.get("inputValue") == '') {
        url_InputValue = '';
    }
    if (url.searchParams.get("showApiStatus") != null && url.searchParams.get("showApiStatus") != undefined) {
        apiUrlParam = url.searchParams.get("showApiStatus");
    }
})

function onLoad (result) {
    var inputId = document.getElementById("selectInput");
    if (inputId.value == null || inputId.value == "") {
        document.getElementById("notice").style.display = "block";
    } else {
        document.getElementById("notice").style.display = "none";
    }
    $(".bootstrap-table").show();
    var headers = new Headers();
    fetch(result + "/rest/metadata/v2.0/xobjects/filter", {
        headers,
        method: "GET",
    })
        .then((response) => response.json())
        .then((data) => {
            allObjectInfoDataArr = data["data"]["records"];
            var jsonColumns = [];
            jsonColumns.push({ checkbox: true, width: 15, class: "checkbox-col" });
            Object.keys(data["data"]["records"][0]).forEach(function (key) {
                if (key == "labelKey") {
                    return;
                }
                if (key == "detail") {
                    return;
                }
                if (key == "nameItem") {
                    return;
                }
                if (key == "iconId") {
                    return;
                }
                if (key == "businessCategory") {
                    return;
                }

                if (key == "apiKey") {
                    jsonColumns.push({
                        field: key,
                        width: 95,
                    });
                } else if (key == "label") {
                }
            });
            jsonColumns.push({
                field: "123",
                width: 85,
                events: {
                    "click #nav2ListView": function (e, value, row, index) {
                        navigation2ListView(row);
                    },
                    "click #nav2ObjMange": function (e, value, row, index) {
                        navigation2ObjectManage(row);
                    },
                    "click #querys": function (e, value, row, index) {
                        checkObjectIsSpecial2Querys(row, true);
                    },
                    "click #queryObject": function (e, value, row, index) {
                        checkObjectIsSpecial2Querys(row, false);
                    },
                },
                formatter: buttonFormatter,
            });

            $("#table").bootstrapTable("destroy");
            $("#table").bootstrapTable({
                data: data["data"]["records"],
                pagination: false,
                paginationVAlign: "top", 
                paginationHAlign: "left", 
                paginationDetailHAlign: "right",
                sortName: "objectId",
                sortOrder: "asc",
                columns: jsonColumns,
                onCheckAll: function (row) {
                    var checkedAllRows = getSelections("table");
                    hasCreateSelectCountObj(checkedAllRows.length);
                },
                onUncheckAll: function (row) {
                    var uncheckedAllRows = getSelections("table");
                    hasCreateSelectCountObj(uncheckedAllRows.length);
                },
                onCheck: function (row) {
                    var checkedRows = getSelections("table");
                    hasCreateSelectCountObj(checkedRows.length);
                },
                onUncheck: function (row) {
                    var unCheckedRows = getSelections("table");
                    hasCreateSelectCountObj(unCheckedRows.length);
                },
            });
            var row = $("#table tr").length;
            var tr = $("#table tr");
            for (i = 1; i < row; i++) { 
                var td = tr.eq(i).children('td').eq(1); 
                data["data"]["records"].forEach(function (item, index, key) {
                    if (td.eq(0).text() == item.apiKey) {
                        td.eq(0).text(" ");
                        td.append("<div style='font-size:14px;'>" + item.label + "<div style='color:#909090;font-size:12px;'>" + item.apiKey + "</div></div>");

                    }
                })
            }
            if (url_InputValue == null || url_InputValue == "") {
            } else {
                fallBackObjectData(url_InputValue);
                document.getElementById("selectInput").value = url_InputValue;
            }
            hasCreateSelectCountObj(0);
            $("[data-toggle='tooltip']").tooltip();
        })
        .catch((error) => {
            console.error("Error:", error);
        });
}

function fallBackObjectData (inputValue) {
    document.getElementById("notice").style.display = "none";
    var filter = inputValue.toUpperCase().trim();
    $("#table").bootstrapTable("destroy");
    createAllObjectData(filter);
    tableHeight = document.getElementById("table").offsetHeight;
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": 900 };
    mess(messName, message);
}

function createAllObjectData (param) {
    var jsonColumns = [];
    jsonColumns.push({ checkbox: true, width: 15, class: "checkbox-col" });
    Object.keys(allObjectInfoDataArr[0]).forEach(function (key) {
        if (key == "labelKey") {
            return;
        }
        if (key == "detail") {
            return;
        }
        if (key == "nameItem") {
            return;
        }
        if (key == "iconId") {
            return;
        }
        if (key == "businessCategory") {
            return;
        }

        if (key == "apiKey") {
            jsonColumns.push({
                field: key,
                width: 95,
            });
        } else if (key == "label") {
        }
    });
    jsonColumns.push({
        field: "123",
        width: 85,
        events: {
            "click #nav2ListView": function (e, value, row, index) {
                navigation2ListView(row);
            },
            "click #nav2ObjMange": function (e, value, row, index) {
                navigation2ObjectManage(row);
            },
            "click #querys": function (e, value, row, index) {
                checkObjectIsSpecial2Querys(row, true);
            },
            "click #queryObject": function (e, value, row, index) {
                checkObjectIsSpecial2Querys(row, false);
            },
        },
        formatter: buttonFormatter,
    });
    var newQueryObjectArr = [];
    allObjectInfoDataArr.forEach((item, index, key) => {
        if (item.apiKey.toUpperCase().indexOf(param) > -1 || item.label.toUpperCase().indexOf(param) > -1) {
            newQueryObjectArr.push(item);
        }
    })

    if (newQueryObjectArr.length == 0) {
        document.getElementById("btn-group").style.display = "none";
    } else {
        document.getElementById("btn-group").style.display = "block";
    }

    $("#table").bootstrapTable("destroy");
    $("#table").bootstrapTable({
        data: newQueryObjectArr,
        pagination: false,
        paginationVAlign: "top", 
        paginationHAlign: "left", 
        paginationDetailHAlign: "right", 
        sortName: "objectId",
        sortOrder: "asc",
        columns: jsonColumns,
        onCheckAll: function (row) {
            var checkedAllRows = getSelections("table");
            hasCreateSelectCountObj(checkedAllRows.length);
        },
        onUncheckAll: function (row) {
            var uncheckedAllRows = getSelections("table");
            hasCreateSelectCountObj(uncheckedAllRows.length);
        },
        onCheck: function (row) {
            var checkedRows = getSelections("table");
            hasCreateSelectCountObj(checkedRows.length);
        },
        onUncheck: function (row) {
            var unCheckedRows = getSelections("table");
            hasCreateSelectCountObj(unCheckedRows.length);
        },
    });
    var row = $("#table tr").length;
    var tr = $("#table tr");
    for (i = 1; i < row; i++) { 
        var td = tr.eq(i).children('td').eq(1); 
        allObjectInfoDataArr.forEach(function (item, index, key) {
            if (td.eq(0).text() == item.apiKey) {
                td.eq(0).text(" ");
                td.append("<div style='font-size:14px;'>" + item.label + "<div style='color:#909090;font-size:12px;'>" + item.apiKey + "</div></div>");

            }
        })
    }
    hasCreateSelectCountObj(getSelections("table").length);
    $("[data-toggle='tooltip']").tooltip();
}

function checkObjectIsSpecial2Querys (row, stepCheck) {
    if (stepCheck) {
        querys(row);
    } else {
        queryObject(row);
    }

}

function navigation2ListView (row) {
    apiKey = JSON.parse(JSON.stringify(row)).apiKey;
    label = JSON.parse(JSON.stringify(row)).label;
    var finalUrl = results;
    var headers = new Headers();
    if (apiKey.indexOf('__c') != -1) {
        fetch(finalUrl + `/rest/metadata/v2.0/xobjects/filter?custom=true&active=true&label=` + label, {
            headers,
            method: "GET",
        })
            .then((response) => response.json())
            .then((data) => {
                var returnData = data["data"]["records"];
                var returnObjId = returnData[0].objectId;
                window.open(finalUrl + "/index.action#/spa/customize.action?belongId=" + returnObjId);
            })
    } else { 
        window.open(finalUrl + "/index.action#/spa/" + apiKey + ".action");
    }
}

function navigation2ObjectManage (row) {
    apiKey = JSON.parse(JSON.stringify(row)).apiKey;
    label = JSON.parse(JSON.stringify(row)).label;
    var finalUrl = results;
    var headers = new Headers();
    if (apiKey.indexOf('__c') != -1) {
        fetch(finalUrl + `/rest/metadata/v2.0/xobjects/filter?custom=true&active=true&label=` + label, {
            headers,
            method: "GET",
        })
            .then((response) => response.json())
            .then((data) => {
                var returnData = data["data"]["records"];
                var returnObjId = returnData[0].objectId;
                window.open(finalUrl + "/bff/webadmin/object/customizeObjectDetail/" + returnObjId);
            })
    } else { 
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '标准对象暂不支持此功能!';
        return;
    }
}

function hasCreateSelectCountObj (selectCount) {
    $("#selectCountD").remove();
    var selectCountObj = $("#table thead tr th:eq(1)").find("div:eq(0)");
    if (selectCount > 0) {
        if (selectCount < 10) {
            selectCountObj.append("<div id='selectCountD' class='alert alert-secondary' role='alert' style='padding:0;margin-bottom:0;width:67px;font-size:12px;'>" + selectCount + " Selected</div>");
        } else if (selectCount >= 10 && selectCount <= 100) {
            selectCountObj.append("<div id='selectCountD' class='alert alert-secondary' role='alert' style='padding:0;margin-bottom:0;width:76px;font-size:12px;'>" + selectCount + " Selected</div>");
        } else {
            selectCountObj.append("<div id='selectCountD' class='alert alert-secondary' role='alert' style='padding:0;margin-bottom:0;width:83px;font-size:12px;'>" + selectCount + " Selected</div>");
        }
    } else {
        selectCountObj.append("<div id='selectCountD' class='alert alert-warning' role='alert' style='padding:0;margin-bottom:0;width:67px;font-size:12px;'>0 Selected</div>");
    }
}

function getSelections (tableID) {
    var indexs = [];
    var selectCount = $("#" + tableID).bootstrapTable("getData", false);
    allObjectInfoDataArr.forEach((item, index, key) => {
        for (var i = 0; i < selectCount.length; i++) {
            if (selectCount[i].apiKey == item.apiKey) {
                allObjectInfoDataArr.splice(index, 1);
                allObjectInfoDataArr.splice(index, 0, selectCount[i]);
            }
        }
    })
    allObjectInfoDataArr.forEach((item, index, key) => {
        if (item["0"]) {
            indexs.push(item);
        }
    })
    return indexs;
}

function querys (row) {
    var inputId = document.getElementById("selectInput");
    apiKey = JSON.parse(JSON.stringify(row)).apiKey;
    window.location.href = "dataQuery.html?apiKey=" + apiKey + "&page=indexCopy" + "&showApiStatus=" + apiUrlParam + "&inputValue=" + inputId.value;
}

function queryObject (row) {
    apiKey = JSON.parse(JSON.stringify(row)).apiKey;
    let messName = "messqueryObject";
    let message = { "queryObject": apiKey };
    mess(messName, message);
}

$("#selectInput").keyup(function () {
    document.getElementById("table").style.display = "none";
    var inputId = document.getElementById("selectInput");
    if (inputId.value == null || inputId.value == "") {
        document.getElementById("notice").style.display = "block";
    } else {
        document.getElementById("notice").style.display = "none";
    }
    var filter = inputId.value.toUpperCase().trim();
    document.getElementById("table").style.display = "";
    createAllObjectData(filter);
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": 900 };
    mess(messName, message);
});

function rearrange (value, row, index) {
    return "<div style='font-size:14px;'>" + row.label + "<div style='color:#909090;font-size:12px;'>" + row.apiKey + "</div></div>";
}

$("#imgOff").click(function () {
    document.getElementById("notice").style.display = "block";
    var inputId = document.getElementById("selectInput");
    inputId.value = "";
    createAllObjectData(inputId.value);
    document.getElementById("table").style.display = "";
    let messName = "indexCopyAndBackSingle";
    let message = { "tablesHeight": 900 };
    mess(messName, message);
});

function buttonFormatter () {
    return (
        "<a data-toggle='tooltip' data-placement='top' data-original-title='List' data-trigger='hover' href='#'  style='margin-left:10px;margin-right:0px;width:20px;border:1px solid #bbb7b7;border-radius:5px;' id='nav2ListView'><i class='fa fa-list-ul' aria-hidden='true' style='text-align: center;width:20px;color: black;'></i></a>" +
        "<a data-toggle='tooltip' data-placement='top' data-original-title='Setting' data-trigger='hover' href='#' style='margin-left:10px;margin-right:0px;width:20px;border:1px solid #bbb7b7;border-radius:5px;' id='nav2ObjMange'><i class='fa fa-cog' aria-hidden='true' style='text-align: center;width:20px;color: black;'></i></a>" +
        "<a data-toggle='tooltip' data-placement='top' data-original-title='Query Editor' data-trigger='hover' href='#' style='margin-left:10px;margin-right:0px;width:20px;border:1px solid #bbb7b7;border-radius:5px;' id='querys'><i class='fa fa-database' aria-hidden='true' style='text-align: center;width:20px;color: black;'></i></a>" +
        "<a data-toggle='tooltip' data-placement='top' data-original-title='Object Fields' data-trigger='hover' href='#' style='margin-left:10px;margin-right:0px;width:20px;border:1px solid #bbb7b7;border-radius:5px;' id='queryObject'><i class='fa fa-th-large' aria-hidden='true' style='text-align: center;width:20px;color: black;'></i></a>"
    );
}

var selRows;
$("#prevPage").click(function () {
    var pathname = resultUrl.pathname;
    var url_Hash = resultUrl.hash;
    if (pathname.substr(pathname.indexOf('_')) == '_detail.action') {
        var tablesHeight = 0;
        tablesHeight = 407;
        let messName = "tableHeight";
        let message = { "tablesHeight": tablesHeight };
        mess(messName, message);
        location.href = "home.html?showApiStatus=" + apiUrlParam;
    } else if (url_Hash.indexOf('/spa/index.action') == -1) {
        var tablesHeight = 0;
        tablesHeight = 407;
        let messName = "tableHeight";
        let message = { "tablesHeight": tablesHeight };
        mess(messName, message);
        location.href = "home.html?showApiStatus=" + apiUrlParam;
    } else {
        var tablesHeight = 0;
        tablesHeight = 219
        let messName = "tableHeight";
        let message = { "tablesHeight": tablesHeight };
        mess(messName, message);
        location.href = "home.html?showApiStatus=" + apiUrlParam;
    }
});

$("#closebuttonCopy").click(function () {
    let messName = "closebutton";
    let message = {};
    mess(messName, message);
})

var selRows;
var rowsNum = "";
$('#objectFieldsExport').click(function () {
    selRows = getSelections("table");
    excelExport(selRows, results, "objectList");
});

$('#erSvgExport').click(function () {
    selRows = getSelections("table");
    erSvgExport(selRows, results);
});

var objectFieldsExport = document.getElementById("objectFieldsExport");

objectFieldsExport.onmousemove = function() {
    objectFieldsExport.className = "objectFields";
}

objectFieldsExport.onmouseout = function () {
    objectFieldsExport.className = "exportFields";
}

var erSvgExports = document.getElementById("erSvgExport");
erSvgExports.onmousemove = function() {
    erSvgExports.className = "objectFields";
}

erSvgExports.onmouseout = function () {
    erSvgExports.className = "exportFields";
}
