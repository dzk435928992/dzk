$("#issues").click(function () {
    window.open("https://github.com/jntrixpro/XiaoshouyiDevTools/issues");
})

