function excelExport (selRows, resultUrl, functionName) {
    if (selRows.length == 0) {
        $('#exampleModal').modal('show');
        document.getElementById('exampleModalLabel').innerHTML = '温馨提示';
        document.getElementById('modalbody').innerHTML = '请选择要输出的对象！';
        return false;
    }
    if (functionName == 'objectList') {
        document.getElementById("over").style.display = "block";
        document.getElementById("layout").style.display = "block";
    }
    var workbook = new ExcelJS.Workbook();
    const allObjectsWorkSheet = workbook.addWorksheet("Objects");
    var getAllObjWorkSheet = workbook.getWorksheet("Objects");
    getAllObjWorkSheet.columns = [
        { header: "NO", key: "NO", width: 7 },
        { header: "对象标签", key: "对象标签", width: 32 },
        { header: "API 名称", key: "API 名称", width: 32 },
        { header: "对象类型", key: "对象类型", width: 32 },
        { header: "启用状态", key: "启用状态", width: 32 },
    ];

    var globalTabStyle = {
        top: { style: "thin" },
        left: { style: "thin" },
        bottom: { style: "thin" },
        right: { style: "thin" },
    };

    var colorTabStyle = {
        type: "pattern",
        pattern: "solid",
        fgColor: { argb: "2A94D5" },
    };

    var fontTabStyle = { size: 12, color: { argb: "FFFFFF" } };
    const firstCol = getAllObjWorkSheet.getColumn(1);
    firstCol.alignment = { vertical: "middle", horizontal: "center" };
    const firstRow = getAllObjWorkSheet.getRow(1);
    firstRow.height = 27;
    getAllObjWorkSheet.getCell("A1").border = globalTabStyle;
    getAllObjWorkSheet.getCell("A1").fill = colorTabStyle;
    getAllObjWorkSheet.getCell("A1").style.font = fontTabStyle;
    getAllObjWorkSheet.getCell("B1").border = globalTabStyle;
    getAllObjWorkSheet.getCell("B1").fill = colorTabStyle;
    getAllObjWorkSheet.getCell("B1").style.font = fontTabStyle;
    getAllObjWorkSheet.getCell("B1").alignment = { vertical: "middle" };
    getAllObjWorkSheet.getCell("C1").border = globalTabStyle;
    getAllObjWorkSheet.getCell("C1").fill = colorTabStyle;
    getAllObjWorkSheet.getCell("C1").style.font = fontTabStyle;
    getAllObjWorkSheet.getCell("C1").alignment = { vertical: "middle" };
    getAllObjWorkSheet.getCell("D1").border = globalTabStyle;
    getAllObjWorkSheet.getCell("D1").fill = colorTabStyle;
    getAllObjWorkSheet.getCell("D1").style.font = fontTabStyle;
    getAllObjWorkSheet.getCell("D1").alignment = { vertical: "middle" };
    getAllObjWorkSheet.getCell("E1").border = globalTabStyle;
    getAllObjWorkSheet.getCell("E1").fill = colorTabStyle;
    getAllObjWorkSheet.getCell("E1").style.font = fontTabStyle;
    getAllObjWorkSheet.getCell("E1").alignment = { vertical: "middle" };

    var j = 2;
    Object.keys(selRows).forEach(function (record, index) {
        const row = getAllObjWorkSheet.getRow(j);
        row.height = 21.6;
        var newRowValue = {};
        newRowValue = selRows[record];
        row.getCell(1).value = index + 1;
        row.getCell(1).border = globalTabStyle;
        row.getCell(1).alignment = { vertical: "middle", horizontal: "center" };
        row.getCell(1).style.font = { size: 12 };
        row.getCell(2).value = newRowValue.label;
        row.getCell(2).border = globalTabStyle;
        row.getCell(2).alignment = { vertical: "middle" };
        row.getCell(2).style.font = { size: 12 };
        row.getCell(3).value = newRowValue.apiKey;
        row.getCell(3).border = globalTabStyle;
        row.getCell(3).alignment = { vertical: "middle" };
        row.getCell(3).style.font = { size: 12 };
        if (newRowValue.custom) {
            row.getCell(4).value = "自定义对象";
        } else {
            row.getCell(4).value = "标准对象";
        }
        row.getCell(4).border = globalTabStyle;
        row.getCell(4).alignment = { vertical: "middle", horizontal: "left" };
        row.getCell(4).style.font = { size: 12 };
        if (newRowValue.active) {
            row.getCell(5).value = "启用";
        } else {
            row.getCell(5).value = "禁用";
        }
        row.getCell(5).border = globalTabStyle;
        row.getCell(5).alignment = { vertical: "middle", horizontal: "left" };
        row.getCell(5).style.font = { size: 12 };
        j++;
    });

    let doFlag = [];
    selRows.forEach((a) => {
        var sheet1 = workbook.addWorksheet(
            a.apiKey
        );
        if (a.apiKey.length > 30) {
            sheetName = a.apiKey;
            sheetName = sheetName.substring(0, 31);
            var worksheet = workbook.getWorksheet(sheetName);
        } else {
            var worksheet = workbook.getWorksheet(
                a.apiKey
            );
        }

        var eneityMap = [];
        fetch(resultUrl + '/rest/data/v2.0/xobjects/' + a.apiKey + '/busiType', {
            headers: {},
            method: "GET",
        })
            .then((response) => response.json())
            .then((data) => {
                for (var i = 0; i < data["data"]["records"].length; i++) {
                    eneityMap.push({ index: i + 1, id: data["data"]["records"][i].id, label: data["data"]["records"][i].label });
                }
            })
            .catch((error) => {
                console.error("Error:", error);
            });

        fetch(resultUrl + '/rest/data/v2.0/xobjects/' + a.apiKey + '/description', {
            headers: {},
            method: "GET",
        })
            .then((response) => response.json())
            .then((dataT) => {
                if (dataT == undefined) {
                    return;
                }
                var fontStyle = {
                    size: 12,
                };
                var contentMiddleOneStyle = {
                    vertical: "middle",
                };
                var contentMiddleTwoStyle = {
                    vertical: "middle",
                    horizontal: "center",
                };

                if (
                    dataT["data"]["fields"][0] != null &&
                    dataT["data"]["fields"][0] != undefined
                ) {
                    var mycolumns = [];
                    var copyColumns = [];
                    mycolumns.push({ header: "NO", key: "NO" });
                    copyColumns.push("NO");

                    Object.keys(dataT["data"]["fields"][0]).forEach(function (field) {
                        mycolumns.push({ header: field, key: field, width: 10 });
                        copyColumns.push(field);
                    });
                    worksheet.columns = mycolumns;
                    for (var i = 1; i < worksheet.getRow(1).values.length; i++) {
                        worksheet.getRow(1).getCell(i).value = "";
                    }
                    worksheet.getRow(1).getCell(1).value = "对象";
                    worksheet.getRow(1).getCell(1).fill = colorTabStyle;
                    worksheet.getRow(1).getCell(3).value = dataT["data"]["label"];
                    worksheet.mergeCells("A1:B1");
                    worksheet.getRow(2).getCell(1).value = "API 名称";
                    worksheet.getRow(2).getCell(1).fill = colorTabStyle;
                    worksheet.getRow(2).getCell(3).value = dataT["data"]["apiKey"];
                    worksheet.getRow(1).getCell(1).border = globalTabStyle;
                    worksheet.getRow(1).getCell(2).border = globalTabStyle;
                    worksheet.getRow(2).getCell(1).border = globalTabStyle;
                    worksheet.getRow(2).getCell(2).border = globalTabStyle;
                    worksheet.mergeCells("A2:B2");

                    worksheet.getCell("A1").alignment = contentMiddleTwoStyle;
                    worksheet.getCell("A1").style.font = fontTabStyle;
                    worksheet.getCell("A2").alignment = contentMiddleTwoStyle;
                    worksheet.getCell("A2").style.font = fontTabStyle;
                    worksheet.getCell("C1").style.font = fontStyle;
                    worksheet.getCell("C1").alignment = contentMiddleOneStyle;
                    worksheet.getCell("C1").border = globalTabStyle;
                    worksheet.getCell("C2").style.font = fontStyle;
                    worksheet.getCell("C2").alignment = contentMiddleOneStyle;
                    worksheet.getCell("C2").border = globalTabStyle;

                    const dobOneCol = worksheet.getColumn(1);
                    dobOneCol.width = 30;
                    const dobOneRow = worksheet.getRow(1);
                    dobOneRow.height = 27;
                    const dobTwoRow = worksheet.getRow(2);
                    dobTwoRow.height = 27;

                    worksheet.getRow(4).getCell(1).value = "NO";
                    worksheet.getRow(4).getCell(2).value = "业务类型Id";
                    worksheet.getRow(4).getCell(3).value = "业务类型名称";
                    worksheet.getRow(4).getCell(1).fill = colorTabStyle;
                    worksheet.getRow(4).getCell(2).fill = colorTabStyle;
                    worksheet.getRow(4).getCell(3).fill = colorTabStyle;

                    worksheet.getRow(4).getCell(1).border = globalTabStyle;
                    worksheet.getRow(4).getCell(2).border = globalTabStyle;
                    worksheet.getRow(4).getCell(3).border = globalTabStyle;
                    const entityRow = worksheet.getRow(4);
                    worksheet.getRow(4).alignment = contentMiddleTwoStyle;
                    worksheet.getRow(4).style.font = fontTabStyle;
                    worksheet.getCell("A1").style.font = fontTabStyle;
                    entityRow.height = 27;
                    for (var i = 0; i < eneityMap.length; i++) {
                        worksheet.getRow(4 + i + 1).getCell(1).value = eneityMap[i].index;
                        worksheet.getRow(4 + i + 1).getCell(2).value = eneityMap[i].id.toString();
                        worksheet.getRow(4 + i + 1).getCell(3).value = eneityMap[i].label;
                        worksheet.getRow(4 + i + 1).getCell(1).border = globalTabStyle;
                        worksheet.getRow(4 + i + 1).getCell(2).border = globalTabStyle;
                        worksheet.getRow(4 + i + 1).getCell(3).border = globalTabStyle;
                        worksheet.getRow(4 + i + 1).height = 21.6;
                        worksheet.getRow(4 + i + 1).alignment = contentMiddleTwoStyle;
                    }

                    var hangshu = 4 + eneityMap.length + 2;
                    worksheet.getRow(hangshu).values = copyColumns;
                    worksheet.getRow(hangshu).height = 27.6;
                    const noCol = worksheet.getColumn(1);
                    noCol.width = 7;
                    const keyCol = worksheet.getColumn(2);
                    keyCol.width = 32;
                    const valueCol = worksheet.getColumn(3);
                    valueCol.width = 32;

                    for (var i = 1; i < worksheet.getRow(hangshu).values.length; i++) {
                        if (i == 1) {
                            worksheet.getRow(hangshu).getCell(i).alignment =
                                contentMiddleTwoStyle;
                        } else {
                            worksheet.getRow(hangshu).getCell(i).alignment = {
                                vertical: "middle",
                            };
                        }
                        worksheet.getRow(hangshu).getCell(i).style.font = fontTabStyle;
                        worksheet.getRow(hangshu).getCell(i).border = globalTabStyle;
                        worksheet.getRow(hangshu).getCell(i).fill = colorTabStyle;
                    }
                    rowsNum = hangshu;
                } else {
                    worksheet.getRow(1).getCell(1).value = "对象";
                    worksheet.getRow(1).getCell(1).fill = colorTabStyle;
                    worksheet.getRow(1).getCell(3).value = dataT["data"]["label"];
                    worksheet.mergeCells("A1:B1");

                    worksheet.getRow(2).getCell(1).value = "API 名称";
                    worksheet.getRow(2).getCell(1).fill = colorTabStyle;
                    worksheet.getRow(2).getCell(3).value = dataT["data"]["apiKey"];

                    worksheet.getRow(1).getCell(1).border = globalTabStyle;
                    worksheet.getRow(1).getCell(2).border = globalTabStyle;
                    worksheet.getRow(2).getCell(1).border = globalTabStyle;
                    worksheet.getRow(2).getCell(2).border = globalTabStyle;

                    worksheet.mergeCells("A2:B2");
                    worksheet.getCell("A1").alignment = contentMiddleTwoStyle;
                    worksheet.getCell("A1").style.font = fontTabStyle;
                    worksheet.getCell("A2").alignment = contentMiddleTwoStyle;
                    worksheet.getCell("A2").style.font = fontTabStyle;
                    worksheet.getCell("C1").style.font = fontStyle;
                    worksheet.getCell("C1").alignment = contentMiddleOneStyle;
                    worksheet.getCell("C1").border = globalTabStyle;
                    worksheet.getCell("C2").style.font = fontStyle;
                    worksheet.getCell("C2").alignment = contentMiddleOneStyle;
                    worksheet.getCell("C2").border = globalTabStyle;

                    worksheet.getRow(1).height = 27;
                    worksheet.getRow(2).height = 27;
                    const noCol = worksheet.getColumn(1);
                    noCol.width = 7;
                    const keyCol = worksheet.getColumn(2);
                    keyCol.width = 32;
                    const valueCol = worksheet.getColumn(3);
                    valueCol.width = 32;
                }

                var j = rowsNum + 1; 
                Object.keys(dataT["data"]["fields"]).forEach(function (record, index) {
                    const row = worksheet.getRow(j);
                    row.height = 21.6;
                    var newRowValue = {};
                    newRowValue = dataT["data"]["fields"][record];
                    newRowValue.NO = index + 1;
                    var objectReferTo;
                    for (var referTo in newRowValue.referTo) {
                        objectReferTo = newRowValue.referTo[referTo];
                    }
                    newRowValue.referTo = objectReferTo;
                    var objectSelectItem = "";
                    if (newRowValue.selectitem.length > 0) {
                        for (var i = 0; i < newRowValue.selectitem.length; i++) {
                            objectSelectItem += newRowValue.selectitem[i].label + ";";
                        }
                        objectSelectItem = objectSelectItem.slice(0, -1);
                        newRowValue.selectitem = objectSelectItem;
                    } else {
                        var newRowValueAndNull = newRowValue.selectitem = "";
                        objectSelectItem = newRowValueAndNull;
                    }

                    var obejctmultItem = "";
                    if (newRowValue.checkitem.length != 0) {
                        for (var i = 0; i < newRowValue.checkitem.length; i++) {
                            obejctmultItem += newRowValue.checkitem[i].label + ";";
                        }
                        obejctmultItem = obejctmultItem.slice(0, -1);
                        newRowValue.checkitem = obejctmultItem;
                    } else {
                        var checkNull = newRowValue.checkitem = "";
                        objectSelectItem = checkNull;
                        newRowValue.checkitem = objectSelectItem;
                    }
                    row.values = newRowValue;
                    for (var i = 1; i < row.values.length; i++) {
                        if (row.getCell(i).value == null) {
                            row.getCell(i).value = " ";
                        }
                        row.getCell(i).border = globalTabStyle;
                        row.getCell(i).alignment = { vertical: "middle" };
                    }
                    row.getCell(1).alignment = contentMiddleTwoStyle;
                    row.getCell(1).style.font = fontStyle;
                    row.commit();
                    j++;
                });

                doFlag.push("done");
                if (selRows.length == doFlag.length) {
                    workbook.xlsx.writeBuffer().then((buf) => {
                        var columns = worksheet.columns;
                        columns.fill = colorTabStyle;
                        var outPutName;
                        if(functionName == 'objectList'){
                            outPutName = "销售易-对象设计书.xlsx";
                        }else{
                            outPutName = selRows[0].label + "-对象设计书.xlsx"
                        }
                        saveAs(new Blob([buf]), outPutName);
                        if (functionName == 'objectList') {
                            document.getElementById("over").style.display = "none";
                            document.getElementById("layout").style.display = "none";
                        }
                    });
                }
            })
            .catch((errort) => {
            })
    });

}